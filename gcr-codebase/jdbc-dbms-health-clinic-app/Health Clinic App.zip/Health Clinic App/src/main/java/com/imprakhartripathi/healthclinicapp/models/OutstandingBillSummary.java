package com.imprakhartripathi.healthclinicapp.models;

import java.math.BigDecimal;

public class OutstandingBillSummary {
    private String patientName;
    private int count;
    private BigDecimal total;

    public OutstandingBillSummary(String patientName, int count, BigDecimal total) {
        this.patientName = patientName;
        this.count = count;
        this.total = total;
    }

    public String getPatientName() {
        return patientName;
    }

    public int getCount() {
        return count;
    }

    public BigDecimal getTotal() {
        return total;
    }
}
