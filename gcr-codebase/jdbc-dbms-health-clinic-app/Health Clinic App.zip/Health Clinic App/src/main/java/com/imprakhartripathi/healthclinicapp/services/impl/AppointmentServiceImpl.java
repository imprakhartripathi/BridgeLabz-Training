package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.AvailabilitySlot;
import com.imprakhartripathi.healthclinicapp.models.DailyScheduleEntry;
import com.imprakhartripathi.healthclinicapp.services.AppointmentService;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class AppointmentServiceImpl implements AppointmentService {
    private final DbOperations dbOperations;

    public AppointmentServiceImpl() {
        this(new DbOperations());
    }

    AppointmentServiceImpl(DbOperations dbOperations) {
        this.dbOperations = dbOperations;
    }

    @Override
    public long bookAppointment(long patientId, long doctorId, LocalDate date, LocalTime time) {
        return dbOperations.bookAppointment(patientId, doctorId, date, time);
    }

    @Override
    public List<AvailabilitySlot> checkDoctorAvailability(long doctorId, LocalDate date) {
        return dbOperations.checkDoctorAvailability(doctorId, date);
    }

    @Override
    public void cancelAppointment(long appointmentId, String changedBy) {
        dbOperations.cancelAppointment(appointmentId, changedBy);
    }

    @Override
    public void rescheduleAppointment(long appointmentId, long doctorId, LocalDate newDate, LocalTime newTime) {
        dbOperations.rescheduleAppointment(appointmentId, doctorId, newDate, newTime);
    }

    @Override
    public List<DailyScheduleEntry> viewDailySchedule(LocalDate date) {
        return dbOperations.viewDailySchedule(date);
    }
}
