package com.imprakhartripathi.healthclinicapp.models;

import java.time.LocalDateTime;

public class AuditLogEntry {
    private String tableName;
    private String action;
    private long rowId;
    private LocalDateTime changedAt;
    private String changedBy;

    public AuditLogEntry(String tableName, String action, long rowId, LocalDateTime changedAt, String changedBy) {
        this.tableName = tableName;
        this.action = action;
        this.rowId = rowId;
        this.changedAt = changedAt;
        this.changedBy = changedBy;
    }

    public String getTableName() {
        return tableName;
    }

    public String getAction() {
        return action;
    }

    public long getRowId() {
        return rowId;
    }

    public LocalDateTime getChangedAt() {
        return changedAt;
    }

    public String getChangedBy() {
        return changedBy;
    }
}
