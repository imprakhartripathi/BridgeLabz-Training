package com.imprakhartripathi.healthclinicapp.dao.impl;

import com.imprakhartripathi.healthclinicapp.dao.PatientDao;
import com.imprakhartripathi.healthclinicapp.models.Patient;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;
import java.util.List;

public class PatientDaoImpl implements PatientDao {
    private final DbOperations dbOperations;

    public PatientDaoImpl() {
        this.dbOperations = new DbOperations();
    }

    @Override
    public long save(Patient patient) {
        return dbOperations.savePatient(patient);
    }

    @Override
    public void update(long id, Patient patient) {
        dbOperations.updatePatient(id, patient);
    }

    @Override
    public List<Patient> findAll() {
        return dbOperations.findAllPatients();
    }

    @Override
    public Patient findByPhone(String phone) {
        return dbOperations.findPatientByPhone(phone);
    }

    @Override
    public Patient findById(long id) {
        return dbOperations.findPatientById(id);
    }

    @Override
    public List<Patient> searchByName(String nameLike) {
        return dbOperations.searchPatientsByName(nameLike);
    }
}
