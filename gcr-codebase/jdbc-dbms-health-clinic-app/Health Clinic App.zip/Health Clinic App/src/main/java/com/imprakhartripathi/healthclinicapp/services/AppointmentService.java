package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.models.AvailabilitySlot;
import com.imprakhartripathi.healthclinicapp.models.DailyScheduleEntry;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface AppointmentService {
    long bookAppointment(long patientId, long doctorId, LocalDate date, LocalTime time);
    List<AvailabilitySlot> checkDoctorAvailability(long doctorId, LocalDate date);
    void cancelAppointment(long appointmentId, String changedBy);
    void rescheduleAppointment(long appointmentId, long doctorId, LocalDate newDate, LocalTime newTime);
    List<DailyScheduleEntry> viewDailySchedule(LocalDate date);
}
