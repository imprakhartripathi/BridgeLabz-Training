package com.imprakhartripathi.healthclinicapp.models;

import java.math.BigDecimal;

public class Doctor {
    private long id;
    private String name;
    private String contact;
    private BigDecimal consultationFee;
    private long specialtyId;
    private boolean active;
    private int maxPatientsPerSlot;

    public Doctor() {
    }

    public Doctor(long id, String name, String contact, BigDecimal consultationFee, long specialtyId,
                  boolean active, int maxPatientsPerSlot) {
        this.id = id;
        this.name = name;
        this.contact = contact;
        this.consultationFee = consultationFee;
        this.specialtyId = specialtyId;
        this.active = active;
        this.maxPatientsPerSlot = maxPatientsPerSlot;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public BigDecimal getConsultationFee() {
        return consultationFee;
    }

    public void setConsultationFee(BigDecimal consultationFee) {
        this.consultationFee = consultationFee;
    }

    public long getSpecialtyId() {
        return specialtyId;
    }

    public void setSpecialtyId(long specialtyId) {
        this.specialtyId = specialtyId;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getMaxPatientsPerSlot() {
        return maxPatientsPerSlot;
    }

    public void setMaxPatientsPerSlot(int maxPatientsPerSlot) {
        this.maxPatientsPerSlot = maxPatientsPerSlot;
    }
}
