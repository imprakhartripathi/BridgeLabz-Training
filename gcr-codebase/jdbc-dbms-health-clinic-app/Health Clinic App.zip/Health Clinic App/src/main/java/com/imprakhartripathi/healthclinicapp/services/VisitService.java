package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.models.MedicalHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.PatientVisitHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.Prescription;

import java.util.List;

public interface VisitService {
    long recordVisit(long appointmentId, long patientId, long doctorId, String diagnosis, String notes);
    void addPrescriptions(long visitId, List<Prescription> prescriptions);
    List<PatientVisitHistoryEntry> viewPatientVisitHistory(long patientId);
    List<MedicalHistoryEntry> viewPatientMedicalHistory(long patientId);
}
