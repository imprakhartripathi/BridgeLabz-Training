package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.models.AuditLogEntry;

import java.io.File;
import java.util.List;

public interface AdminService {
    List<AuditLogEntry> viewAuditLogs(String tableName, String action);
    File backupToCsv(String outputDir);
}
