package com.imprakhartripathi.healthclinicapp.models;

public class Specialty {
    private long id;
    private String name;

    public Specialty() {
    }

    public Specialty(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
