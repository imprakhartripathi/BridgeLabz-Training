package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.models.Patient;

import java.util.List;

public interface PatientService {

    long registerPatient(Patient patient);

    void updatePatient(long id, Patient patient);

    List<Patient> getAllPatients();

    Patient getPatientByPhone(String phone);

    Patient getPatientById(long id);

    List<Patient> searchPatientsByName(String nameLike);
}
