package com.imprakhartripathi.healthclinicapp;

import com.imprakhartripathi.healthclinicapp.models.AvailabilitySlot;
import com.imprakhartripathi.healthclinicapp.models.BillItem;
import com.imprakhartripathi.healthclinicapp.models.DailyScheduleEntry;
import com.imprakhartripathi.healthclinicapp.models.MedicalHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.OutstandingBillSummary;
import com.imprakhartripathi.healthclinicapp.models.Patient;
import com.imprakhartripathi.healthclinicapp.models.PatientVisitHistoryEntry;
import com.imprakhartripathi.healthclinicapp.services.AppointmentService;
import com.imprakhartripathi.healthclinicapp.services.BillingService;
import com.imprakhartripathi.healthclinicapp.services.PatientService;
import com.imprakhartripathi.healthclinicapp.services.VisitService;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

final class ReceptionConsole {
    private final PatientService patientService;
    private final AppointmentService appointmentService;
    private final VisitService visitService;
    private final BillingService billingService;

    ReceptionConsole(PatientService patientService,
                     AppointmentService appointmentService,
                     VisitService visitService,
                     BillingService billingService) {
        this.patientService = patientService;
        this.appointmentService = appointmentService;
        this.visitService = visitService;
        this.billingService = billingService;
    }

    void run(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Receptionist Menu ---");
            System.out.println("1. Register Patient");
            System.out.println("2. Update Patient");
            System.out.println("3. Search Patients");
            System.out.println("4. View Patient Visit History");
            System.out.println("5. Book Appointment");
            System.out.println("6. Check Doctor Availability");
            System.out.println("7. Cancel Appointment");
            System.out.println("8. Reschedule Appointment");
            System.out.println("9. View Daily Appointment Schedule");
            System.out.println("10. Generate Bill");
            System.out.println("11. Record Payment");
            System.out.println("12. View Outstanding Bills");
            System.out.println("0. Back");

            int choice = ConsoleUtils.readInt(scanner, "Choose option: ");
            switch (choice) {
                case 1 -> registerPatient(scanner);
                case 2 -> updatePatient(scanner);
                case 3 -> searchPatients(scanner);
                case 4 -> viewPatientVisitHistory(scanner);
                case 5 -> bookAppointment(scanner);
                case 6 -> checkAvailability(scanner);
                case 7 -> cancelAppointment(scanner);
                case 8 -> rescheduleAppointment(scanner);
                case 9 -> viewDailySchedule(scanner);
                case 10 -> generateBill(scanner);
                case 11 -> recordPayment(scanner);
                case 12 -> viewOutstandingBills();
                case 0 -> back = true;
                default -> System.out.println("Invalid option");
            }
        }
    }

    private void registerPatient(Scanner scanner) {
        String name = ConsoleUtils.readNonBlank(scanner, "Enter name: ");
        LocalDate dob = ConsoleUtils.readDate(scanner, "Enter DOB (yyyy-MM-dd): ");
        String phone = ConsoleUtils.readNonBlank(scanner, "Enter phone: ");
        String email = ConsoleUtils.readOptional(scanner, "Enter email (optional): ");
        String address = ConsoleUtils.readOptional(scanner, "Enter address (optional): ");
        String bloodGroup = ConsoleUtils.readOptional(scanner, "Enter blood group (optional): ");

        Patient patient = new Patient(name, dob, phone, email, address, bloodGroup);
        long id = patientService.registerPatient(patient);
        System.out.println("Patient registered successfully with ID: " + id);
    }

    private void updatePatient(Scanner scanner) {
        long id = ConsoleUtils.readLong(scanner, "Enter patient ID: ");
        Patient existing = patientService.getPatientById(id);
        if (existing == null) {
            System.out.println("Patient not found");
            return;
        }

        String name = ConsoleUtils.readOptional(scanner, "Enter name (" + existing.getName() + "): ");
        LocalDate dob = ConsoleUtils.readOptionalDate(scanner, "Enter DOB (" + existing.getDob() + "): ", existing.getDob());
        String phone = ConsoleUtils.readOptional(scanner, "Enter phone (" + existing.getPhone() + "): ");
        String email = ConsoleUtils.readOptional(scanner, "Enter email (" + existing.getEmail() + "): ");
        String address = ConsoleUtils.readOptional(scanner, "Enter address (" + existing.getAddress() + "): ");
        String bloodGroup = ConsoleUtils.readOptional(scanner, "Enter blood group (" + existing.getBloodGroup() + "): ");

        Patient updated = new Patient();
        updated.setName(name == null ? existing.getName() : name);
        updated.setDob(dob);
        updated.setPhone(phone == null ? existing.getPhone() : phone);
        updated.setEmail(email == null ? existing.getEmail() : email);
        updated.setAddress(address == null ? existing.getAddress() : address);
        updated.setBloodGroup(bloodGroup == null ? existing.getBloodGroup() : bloodGroup);

        patientService.updatePatient(id, updated);
        System.out.println("Patient updated successfully");
    }

    private void searchPatients(Scanner scanner) {
        System.out.println("1. Search by Name");
        System.out.println("2. Search by Phone");
        System.out.println("3. Search by ID");
        int choice = ConsoleUtils.readInt(scanner, "Choose option: ");
        switch (choice) {
            case 1 -> {
                List<Patient> patients = patientService.searchPatientsByName(
                        ConsoleUtils.readNonBlank(scanner, "Enter name: ")
                );
                if (patients.isEmpty()) {
                    System.out.println("No patients found.");
                } else {
                    patients.forEach(this::printPatient);
                }
            }
            case 2 -> {
                Patient patient = patientService.getPatientByPhone(
                        ConsoleUtils.readNonBlank(scanner, "Enter phone: ")
                );
                if (patient == null) {
                    System.out.println("Patient not found");
                } else {
                    printPatient(patient);
                }
            }
            case 3 -> {
                Patient patient = patientService.getPatientById(ConsoleUtils.readLong(scanner, "Enter ID: "));
                if (patient == null) {
                    System.out.println("Patient not found");
                } else {
                    printPatient(patient);
                }
            }
            default -> System.out.println("Invalid option");
        }
    }

    private void viewPatientVisitHistory(Scanner scanner) {
        long patientId = ConsoleUtils.readLong(scanner, "Enter patient ID: ");
        List<PatientVisitHistoryEntry> history = visitService.viewPatientVisitHistory(patientId);
        if (history.isEmpty()) {
            System.out.println("No visit history found.");
            return;
        }
        System.out.println("Visit Date | Appt Date Time | Doctor | Diagnosis");
        history.forEach(h -> System.out.println(
                h.getVisitDate() + " | " +
                        h.getAppointmentDate() + " " + h.getAppointmentTime() + " | " +
                        h.getDoctorName() + " | " + h.getDiagnosis()
        ));
    }

    private void bookAppointment(Scanner scanner) {
        long patientId = ConsoleUtils.readLong(scanner, "Enter patient ID: ");
        long doctorId = ConsoleUtils.readLong(scanner, "Enter doctor ID: ");
        LocalDate date = ConsoleUtils.readDate(scanner, "Enter appointment date (yyyy-MM-dd): ");
        LocalTime time = ConsoleUtils.readTime(scanner, "Enter appointment time (HH:mm): ");
        long id = appointmentService.bookAppointment(patientId, doctorId, date, time);
        System.out.println("Appointment booked with ID: " + id);
    }

    private void checkAvailability(Scanner scanner) {
        long doctorId = ConsoleUtils.readLong(scanner, "Enter doctor ID: ");
        LocalDate date = ConsoleUtils.readDate(scanner, "Enter date (yyyy-MM-dd): ");
        List<AvailabilitySlot> slots = appointmentService.checkDoctorAvailability(doctorId, date);
        if (slots.isEmpty()) {
            System.out.println("No bookings for this date.");
            return;
        }
        System.out.println("Time | Booked/Capacity");
        slots.forEach(slot -> System.out.println(
                slot.getTime() + " | " + slot.getBooked() + "/" + slot.getCapacity()
        ));
    }

    private void cancelAppointment(Scanner scanner) {
        long appointmentId = ConsoleUtils.readLong(scanner, "Enter appointment ID: ");
        appointmentService.cancelAppointment(appointmentId, "receptionist");
        System.out.println("Appointment cancelled");
    }

    private void rescheduleAppointment(Scanner scanner) {
        long appointmentId = ConsoleUtils.readLong(scanner, "Enter appointment ID: ");
        long doctorId = ConsoleUtils.readLong(scanner, "Enter doctor ID: ");
        LocalDate date = ConsoleUtils.readDate(scanner, "Enter new date (yyyy-MM-dd): ");
        LocalTime time = ConsoleUtils.readTime(scanner, "Enter new time (HH:mm): ");
        appointmentService.rescheduleAppointment(appointmentId, doctorId, date, time);
        System.out.println("Appointment rescheduled");
    }

    private void viewDailySchedule(Scanner scanner) {
        LocalDate date = ConsoleUtils.readDate(scanner, "Enter date (yyyy-MM-dd): ");
        List<DailyScheduleEntry> entries = appointmentService.viewDailySchedule(date);
        if (entries.isEmpty()) {
            System.out.println("No appointments scheduled.");
            return;
        }
        System.out.println("ID | Time | Patient | Doctor | Status");
        entries.forEach(e -> System.out.println(
                e.getAppointmentId() + " | " + e.getTime() + " | " +
                        e.getPatientName() + " | " + e.getDoctorName() + " | " +
                        e.getStatus()
        ));
    }

    private void generateBill(Scanner scanner) {
        long visitId = ConsoleUtils.readLong(scanner, "Enter visit ID: ");
        long patientId = ConsoleUtils.readLong(scanner, "Enter patient ID: ");
        long doctorId = ConsoleUtils.readLong(scanner, "Enter doctor ID: ");
        int itemCount = ConsoleUtils.readInt(scanner, "Additional charges count: ");
        List<BillItem> items = new ArrayList<>();
        for (int i = 0; i < itemCount; i++) {
            System.out.println("Charge " + (i + 1));
            String description = ConsoleUtils.readNonBlank(scanner, "Description: ");
            BigDecimal amount = ConsoleUtils.readDecimal(scanner, "Amount: ");
            items.add(new BillItem(description, amount));
        }
        long billId = billingService.generateBill(visitId, patientId, doctorId, items);
        System.out.println("Bill generated with ID: " + billId);
    }

    private void recordPayment(Scanner scanner) {
        long billId = ConsoleUtils.readLong(scanner, "Enter bill ID: ");
        BigDecimal amount = ConsoleUtils.readDecimal(scanner, "Enter amount: ");
        String mode = ConsoleUtils.readNonBlank(scanner, "Enter payment mode: ");
        billingService.recordPayment(billId, amount, mode);
        System.out.println("Payment recorded");
    }

    private void viewOutstandingBills() {
        List<OutstandingBillSummary> summaries = billingService.viewOutstandingBills();
        if (summaries.isEmpty()) {
            System.out.println("No outstanding bills.");
            return;
        }
        System.out.println("Patient | Count | Total");
        summaries.forEach(s -> System.out.println(
                s.getPatientName() + " | " + s.getCount() + " | " + s.getTotal()
        ));
    }

    private void printPatient(Patient p) {
        System.out.println(
                p.getId() + " | " + p.getName() + " | " + p.getDob() + " | " +
                        p.getPhone() + " | " + p.getEmail() + " | " +
                        p.getAddress() + " | " + p.getBloodGroup()
        );
    }
}
