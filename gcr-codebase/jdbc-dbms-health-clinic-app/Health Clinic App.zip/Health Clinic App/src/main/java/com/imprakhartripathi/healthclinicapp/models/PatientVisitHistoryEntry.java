package com.imprakhartripathi.healthclinicapp.models;

import java.time.LocalDate;
import java.time.LocalTime;

public class PatientVisitHistoryEntry {
    private LocalDate visitDate;
    private LocalDate appointmentDate;
    private LocalTime appointmentTime;
    private String doctorName;
    private String diagnosis;

    public PatientVisitHistoryEntry(LocalDate visitDate, LocalDate appointmentDate, LocalTime appointmentTime,
                                    String doctorName, String diagnosis) {
        this.visitDate = visitDate;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.doctorName = doctorName;
        this.diagnosis = diagnosis;
    }

    public LocalDate getVisitDate() {
        return visitDate;
    }

    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public LocalTime getAppointmentTime() {
        return appointmentTime;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getDiagnosis() {
        return diagnosis;
    }
}
