package com.imprakhartripathi.healthclinicapp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

final class ConsoleUtils {
    private ConsoleUtils() {
    }

    static String readNonBlank(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            System.out.println("Value cannot be empty. Please try again.");
        }
    }

    static String readOptional(Scanner scanner, String prompt) {
        System.out.print(prompt);
        String value = scanner.nextLine();
        if (value == null || value.trim().isEmpty()) {
            return null;
        }
        return value.trim();
    }

    static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine();
            try {
                return Integer.parseInt(value.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    static long readLong(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine();
            try {
                return Long.parseLong(value.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    static BigDecimal readDecimal(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine();
            try {
                return new BigDecimal(value.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid decimal number.");
            }
        }
    }

    static LocalDate readDate(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine();
            try {
                return LocalDate.parse(value.trim());
            } catch (DateTimeParseException e) {
                System.out.println("Please enter a valid date (yyyy-MM-dd).");
            }
        }
    }

    static LocalDate readOptionalDate(Scanner scanner, String prompt, LocalDate current) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine();
            if (value == null || value.trim().isEmpty()) {
                return current;
            }
            try {
                return LocalDate.parse(value.trim());
            } catch (DateTimeParseException e) {
                System.out.println("Please enter a valid date (yyyy-MM-dd).");
            }
        }
    }

    static LocalTime readTime(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine();
            try {
                return LocalTime.parse(value.trim());
            } catch (DateTimeParseException e) {
                System.out.println("Please enter a valid time (HH:mm).");
            }
        }
    }
}
