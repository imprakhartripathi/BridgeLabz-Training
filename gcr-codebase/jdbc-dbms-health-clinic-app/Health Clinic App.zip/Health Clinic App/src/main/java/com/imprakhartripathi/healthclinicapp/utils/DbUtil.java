package com.imprakhartripathi.healthclinicapp.utils;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public final class DbUtil {

    private static final Properties PROPS = loadProperties();
    private static final HikariDataSource DATA_SOURCE = initDataSource();

    private DbUtil() {
    }

    public static Connection getConnection() throws SQLException {
        return DATA_SOURCE.getConnection();
    }

    private static Properties loadProperties() {
        Properties properties = new Properties();
        try (InputStream in = DbUtil.class.getClassLoader()
                .getResourceAsStream("application.properties")) {
            if (in != null) {
                properties.load(in);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Failed to load application.properties", e);
        }
        return properties;
    }

    private static HikariDataSource initDataSource() {
        String url = firstNonBlank(
                System.getenv("DB_URL"),
                PROPS.getProperty("spring.datasource.url")
        );
        String user = firstNonBlank(
                System.getenv("DB_USER"),
                PROPS.getProperty("spring.datasource.username"),
                PROPS.getProperty("spring.datasource.user")
        );
        String password = firstNonBlank(
                System.getenv("DB_PASSWORD"),
                PROPS.getProperty("spring.datasource.password")
        );
        String driver = firstNonBlank(
                PROPS.getProperty("spring.datasource.driver-class-name"),
                "org.postgresql.Driver"
        );

        if (isBlank(url) || isBlank(user) || password == null) {
            throw new IllegalStateException("Database configuration is not set");
        }

        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(url);
        config.setUsername(user);
        config.setPassword(password);
        config.setDriverClassName(driver);
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(2);
        config.setPoolName("health-clinic-pool");
        return new HikariDataSource(config);
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) {
            if (!isBlank(value)) {
                return value;
            }
        }
        return null;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
