package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.dao.PatientDao;
import com.imprakhartripathi.healthclinicapp.dao.impl.PatientDaoImpl;
import com.imprakhartripathi.healthclinicapp.models.Patient;
import com.imprakhartripathi.healthclinicapp.services.PatientService;
import java.time.LocalDate;
import java.util.List;

public class PatientServiceImpl implements PatientService {

    private final PatientDao patientDao;

    // Default constructor (used by app)
    public PatientServiceImpl() {
        this.patientDao = new PatientDaoImpl();
    }

    // Constructor for tests (package-private on purpose)
    public PatientServiceImpl(PatientDao patientDao) {
        this.patientDao = patientDao;
    }

    @Override
    public long registerPatient(Patient patient) {
        if (patient.getName() == null || patient.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Name is required");
        }
        if (patient.getDob() == null) {
            throw new IllegalArgumentException("DOB is required");
        }
        if (patient.getDob().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("DOB cannot be in the future");
        }
        if (patient.getPhone() == null || patient.getPhone().trim().isEmpty()) {
            throw new IllegalArgumentException("Phone is required");
        }
        return patientDao.save(patient);
    }

    @Override
    public void updatePatient(long id, Patient patient) {
        if (patient.getName() == null || patient.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Name is required");
        }
        if (patient.getDob() == null) {
            throw new IllegalArgumentException("DOB is required");
        }
        if (patient.getDob().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("DOB cannot be in the future");
        }
        if (patient.getPhone() == null || patient.getPhone().trim().isEmpty()) {
            throw new IllegalArgumentException("Phone is required");
        }
        patientDao.update(id, patient);
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientDao.findAll();
    }

    @Override
    public Patient getPatientByPhone(String phone) {
        return patientDao.findByPhone(phone);
    }

    @Override
    public Patient getPatientById(long id) {
        return patientDao.findById(id);
    }

    @Override
    public List<Patient> searchPatientsByName(String nameLike) {
        return patientDao.searchByName(nameLike);
    }
}
