package com.imprakhartripathi.healthclinicapp.models;

public class Prescription {
    private long visitId;
    private String medicineName;
    private String dosage;
    private String duration;
    private String instructions;

    public Prescription(long visitId, String medicineName, String dosage, String duration, String instructions) {
        this.visitId = visitId;
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.duration = duration;
        this.instructions = instructions;
    }

    public long getVisitId() {
        return visitId;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public String getDosage() {
        return dosage;
    }

    public String getDuration() {
        return duration;
    }

    public String getInstructions() {
        return instructions;
    }
}
