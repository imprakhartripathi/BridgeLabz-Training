package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.AuditLogEntry;
import com.imprakhartripathi.healthclinicapp.services.AdminService;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;

import java.io.File;
import java.util.List;

public class AdminServiceImpl implements AdminService {
    private final DbOperations dbOperations;

    public AdminServiceImpl() {
        this(new DbOperations());
    }

    AdminServiceImpl(DbOperations dbOperations) {
        this.dbOperations = dbOperations;
    }

    @Override
    public List<AuditLogEntry> viewAuditLogs(String tableName, String action) {
        return dbOperations.viewAuditLogs(tableName, action);
    }

    @Override
    public File backupToCsv(String outputDir) {
        return dbOperations.backupToCsv(outputDir);
    }
}
