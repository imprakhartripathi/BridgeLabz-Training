package com.imprakhartripathi.healthclinicapp.models;

import java.math.BigDecimal;
import java.time.LocalDate;

public class RevenueReportEntry {
    private LocalDate billDate;
    private String doctorName;
    private String specialtyName;
    private BigDecimal total;

    public RevenueReportEntry(LocalDate billDate, String doctorName, String specialtyName, BigDecimal total) {
        this.billDate = billDate;
        this.doctorName = doctorName;
        this.specialtyName = specialtyName;
        this.total = total;
    }

    public LocalDate getBillDate() {
        return billDate;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getSpecialtyName() {
        return specialtyName;
    }

    public BigDecimal getTotal() {
        return total;
    }
}
