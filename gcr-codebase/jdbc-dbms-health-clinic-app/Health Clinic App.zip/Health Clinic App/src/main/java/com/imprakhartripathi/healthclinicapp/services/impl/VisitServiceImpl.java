package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.MedicalHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.PatientVisitHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.Prescription;
import com.imprakhartripathi.healthclinicapp.services.VisitService;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;

import java.util.List;

public class VisitServiceImpl implements VisitService {
    private final DbOperations dbOperations;

    public VisitServiceImpl() {
        this(new DbOperations());
    }

    VisitServiceImpl(DbOperations dbOperations) {
        this.dbOperations = dbOperations;
    }

    @Override
    public long recordVisit(long appointmentId, long patientId, long doctorId, String diagnosis, String notes) {
        return dbOperations.recordVisit(appointmentId, patientId, doctorId, diagnosis, notes);
    }

    @Override
    public void addPrescriptions(long visitId, List<Prescription> prescriptions) {
        dbOperations.addPrescriptions(visitId, prescriptions);
    }

    @Override
    public List<PatientVisitHistoryEntry> viewPatientVisitHistory(long patientId) {
        return dbOperations.viewPatientVisitHistory(patientId);
    }

    @Override
    public List<MedicalHistoryEntry> viewPatientMedicalHistory(long patientId) {
        return dbOperations.viewPatientMedicalHistory(patientId);
    }
}
