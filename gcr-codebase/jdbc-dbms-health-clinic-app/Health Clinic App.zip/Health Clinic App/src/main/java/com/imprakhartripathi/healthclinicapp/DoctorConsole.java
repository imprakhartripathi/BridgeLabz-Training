package com.imprakhartripathi.healthclinicapp;

import com.imprakhartripathi.healthclinicapp.models.DailyScheduleEntry;
import com.imprakhartripathi.healthclinicapp.models.MedicalHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.Prescription;
import com.imprakhartripathi.healthclinicapp.services.AppointmentService;
import com.imprakhartripathi.healthclinicapp.services.VisitService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

final class DoctorConsole {
    private final AppointmentService appointmentService;
    private final VisitService visitService;

    DoctorConsole(AppointmentService appointmentService, VisitService visitService) {
        this.appointmentService = appointmentService;
        this.visitService = visitService;
    }

    void run(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Doctor Menu ---");
            System.out.println("1. View Daily Appointment Schedule");
            System.out.println("2. Record Patient Visit");
            System.out.println("3. Add Prescription Details");
            System.out.println("4. View Patient Medical History");
            System.out.println("0. Back");

            int choice = ConsoleUtils.readInt(scanner, "Choose option: ");
            switch (choice) {
                case 1 -> viewDailySchedule(scanner);
                case 2 -> recordVisit(scanner);
                case 3 -> addPrescriptions(scanner);
                case 4 -> viewPatientMedicalHistory(scanner);
                case 0 -> back = true;
                default -> System.out.println("Invalid option");
            }
        }
    }

    private void viewDailySchedule(Scanner scanner) {
        List<DailyScheduleEntry> entries = appointmentService
                .viewDailySchedule(ConsoleUtils.readDate(scanner, "Enter date (yyyy-MM-dd): "));
        if (entries.isEmpty()) {
            System.out.println("No appointments scheduled.");
            return;
        }
        System.out.println("ID | Time | Patient | Doctor | Status");
        entries.forEach(e -> System.out.println(
                e.getAppointmentId() + " | " + e.getTime() + " | " +
                        e.getPatientName() + " | " + e.getDoctorName() + " | " +
                        e.getStatus()
        ));
    }

    private void recordVisit(Scanner scanner) {
        long appointmentId = ConsoleUtils.readLong(scanner, "Enter appointment ID: ");
        long patientId = ConsoleUtils.readLong(scanner, "Enter patient ID: ");
        long doctorId = ConsoleUtils.readLong(scanner, "Enter doctor ID: ");
        String diagnosis = ConsoleUtils.readOptional(scanner, "Enter diagnosis (optional): ");
        String notes = ConsoleUtils.readOptional(scanner, "Enter notes (optional): ");
        long visitId = visitService.recordVisit(appointmentId, patientId, doctorId, diagnosis, notes);
        System.out.println("Visit recorded with ID: " + visitId);
    }

    private void addPrescriptions(Scanner scanner) {
        long visitId = ConsoleUtils.readLong(scanner, "Enter visit ID: ");
        int count = ConsoleUtils.readInt(scanner, "How many medicines?: ");
        List<Prescription> prescriptions = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            System.out.println("Medicine " + (i + 1));
            String name = ConsoleUtils.readNonBlank(scanner, "Name: ");
            String dosage = ConsoleUtils.readOptional(scanner, "Dosage (optional): ");
            String duration = ConsoleUtils.readOptional(scanner, "Duration (optional): ");
            String instructions = ConsoleUtils.readOptional(scanner, "Instructions (optional): ");
            prescriptions.add(new Prescription(visitId, name, dosage, duration, instructions));
        }
        visitService.addPrescriptions(visitId, prescriptions);
        System.out.println("Prescriptions added");
    }

    private void viewPatientMedicalHistory(Scanner scanner) {
        long patientId = ConsoleUtils.readLong(scanner, "Enter patient ID: ");
        List<MedicalHistoryEntry> history = visitService.viewPatientMedicalHistory(patientId);
        if (history.isEmpty()) {
            System.out.println("No medical history found.");
            return;
        }
        System.out.println("Visit Date | Appt Date Time | Diagnosis | Medicine | Dosage | Duration");
        history.forEach(h -> System.out.println(
                h.getVisitDate() + " | " +
                        h.getAppointmentDate() + " " + h.getAppointmentTime() + " | " +
                        h.getDiagnosis() + " | " +
                        h.getMedicineName() + " | " +
                        h.getDosage() + " | " +
                        h.getDuration()
        ));
    }
}
