package com.imprakhartripathi.healthclinicapp.dao;

import com.imprakhartripathi.healthclinicapp.models.Patient;

import java.util.List;

public interface PatientDao {

    long save(Patient patient);

    void update(long id, Patient patient);

    List<Patient> findAll();

    Patient findByPhone(String phone);

    Patient findById(long id);

    List<Patient> searchByName(String nameLike);
}
