package com.imprakhartripathi.healthclinicapp.models;

import java.time.LocalTime;

public class DailyScheduleEntry {
    private long appointmentId;
    private LocalTime time;
    private String patientName;
    private String doctorName;
    private String status;

    public DailyScheduleEntry(long appointmentId, LocalTime time, String patientName,
                              String doctorName, String status) {
        this.appointmentId = appointmentId;
        this.time = time;
        this.patientName = patientName;
        this.doctorName = doctorName;
        this.status = status;
    }

    public long getAppointmentId() {
        return appointmentId;
    }

    public LocalTime getTime() {
        return time;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getStatus() {
        return status;
    }
}
