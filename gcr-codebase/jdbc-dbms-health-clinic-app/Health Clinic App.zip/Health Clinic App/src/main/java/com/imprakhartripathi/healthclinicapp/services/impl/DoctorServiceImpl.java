package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.DoctorView;
import com.imprakhartripathi.healthclinicapp.services.DoctorService;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;

import java.math.BigDecimal;
import java.util.List;

public class DoctorServiceImpl implements DoctorService {
    private final DbOperations dbOperations;

    public DoctorServiceImpl() {
        this(new DbOperations());
    }

    DoctorServiceImpl(DbOperations dbOperations) {
        this.dbOperations = dbOperations;
    }

    @Override
    public long addDoctor(String name, String contact, BigDecimal fee, long specialtyId, int maxPerSlot) {
        return dbOperations.addDoctor(name, contact, fee, specialtyId, maxPerSlot);
    }

    @Override
    public void updateDoctorSpecialty(long doctorId, long specialtyId) {
        dbOperations.updateDoctorSpecialty(doctorId, specialtyId);
    }

    @Override
    public List<DoctorView> viewDoctorsBySpecialty(String specialtyName) {
        return dbOperations.viewDoctorsBySpecialty(specialtyName);
    }

    @Override
    public void deactivateDoctor(long doctorId) {
        dbOperations.deactivateDoctor(doctorId);
    }
}
