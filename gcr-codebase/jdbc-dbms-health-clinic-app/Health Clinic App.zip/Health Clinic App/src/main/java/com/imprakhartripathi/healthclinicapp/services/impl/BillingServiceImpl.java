package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.BillItem;
import com.imprakhartripathi.healthclinicapp.models.OutstandingBillSummary;
import com.imprakhartripathi.healthclinicapp.models.RevenueReportEntry;
import com.imprakhartripathi.healthclinicapp.services.BillingService;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class BillingServiceImpl implements BillingService {
    private final DbOperations dbOperations;

    public BillingServiceImpl() {
        this(new DbOperations());
    }

    BillingServiceImpl(DbOperations dbOperations) {
        this.dbOperations = dbOperations;
    }

    @Override
    public long generateBill(long visitId, long patientId, long doctorId, List<BillItem> items) {
        return dbOperations.generateBill(visitId, patientId, doctorId, items);
    }

    @Override
    public void recordPayment(long billId, BigDecimal amount, String mode) {
        dbOperations.recordPayment(billId, amount, mode);
    }

    @Override
    public List<OutstandingBillSummary> viewOutstandingBills() {
        return dbOperations.viewOutstandingBills();
    }

    @Override
    public List<RevenueReportEntry> generateRevenueReport(LocalDate from, LocalDate to) {
        return dbOperations.generateRevenueReport(from, to);
    }
}
