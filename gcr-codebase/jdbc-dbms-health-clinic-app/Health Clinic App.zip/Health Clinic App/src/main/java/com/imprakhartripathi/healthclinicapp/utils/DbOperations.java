package com.imprakhartripathi.healthclinicapp.utils;

import com.imprakhartripathi.healthclinicapp.models.AuditLogEntry;
import com.imprakhartripathi.healthclinicapp.models.AvailabilitySlot;
import com.imprakhartripathi.healthclinicapp.models.BillItem;
import com.imprakhartripathi.healthclinicapp.models.DailyScheduleEntry;
import com.imprakhartripathi.healthclinicapp.models.DoctorView;
import com.imprakhartripathi.healthclinicapp.models.MedicalHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.OutstandingBillSummary;
import com.imprakhartripathi.healthclinicapp.models.Patient;
import com.imprakhartripathi.healthclinicapp.models.PatientVisitHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.Prescription;
import com.imprakhartripathi.healthclinicapp.models.RevenueReportEntry;
import com.imprakhartripathi.healthclinicapp.models.Specialty;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class DbOperations {

    // ---------------------------
    // Patient Operations
    // ---------------------------
    public long savePatient(Patient patient) {
        ensureUniquePatient(patient.getPhone(), patient.getEmail(), null);
        String sql = """
                INSERT INTO patients(name, dob, phone, email, address, blood_group)
                VALUES (?, ?, ?, ?, ?, ?)
                RETURNING id
                """;

        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, patient.getName());
            ps.setDate(2, patient.getDob() == null ? null : Date.valueOf(patient.getDob()));
            ps.setString(3, patient.getPhone());
            ps.setString(4, patient.getEmail());
            ps.setString(5, patient.getAddress());
            ps.setString(6, patient.getBloodGroup());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to save patient", e);
        }
        throw new IllegalStateException("Failed to save patient");
    }

    public void updatePatient(long patientId, Patient updated) {
        ensureUniquePatient(updated.getPhone(), updated.getEmail(), patientId);
        String sql = """
                UPDATE patients
                SET name = ?, dob = ?, phone = ?, email = ?, address = ?, blood_group = ?
                WHERE id = ?
                """;
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, updated.getName());
            ps.setDate(2, updated.getDob() == null ? null : Date.valueOf(updated.getDob()));
            ps.setString(3, updated.getPhone());
            ps.setString(4, updated.getEmail());
            ps.setString(5, updated.getAddress());
            ps.setString(6, updated.getBloodGroup());
            ps.setLong(7, patientId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to update patient", e);
        }
    }

    public List<Patient> findAllPatients() {
        String sql = "SELECT id, name, dob, phone, email, address, blood_group FROM patients ORDER BY id";
        List<Patient> patients = new ArrayList<>();

        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                patients.add(mapPatient(rs));
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to fetch patients", e);
        }

        return patients;
    }

    public Patient findPatientByPhone(String phone) {
        String sql = "SELECT id, name, dob, phone, email, address, blood_group FROM patients WHERE phone = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, phone);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapPatient(rs);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to find patient", e);
        }
        return null;
    }

    public Patient findPatientById(long id) {
        String sql = "SELECT id, name, dob, phone, email, address, blood_group FROM patients WHERE id = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapPatient(rs);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to find patient", e);
        }
        return null;
    }

    public List<Patient> searchPatientsByName(String nameLike) {
        String sql = "SELECT id, name, dob, phone, email, address, blood_group FROM patients WHERE name ILIKE ?";
        List<Patient> patients = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, "%" + nameLike + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    patients.add(mapPatient(rs));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to search patients", e);
        }
        return patients;
    }

    private Patient mapPatient(ResultSet rs) throws SQLException {
        Patient patient = new Patient();
        patient.setId(rs.getLong("id"));
        patient.setName(rs.getString("name"));
        Date dob = rs.getDate("dob");
        patient.setDob(dob == null ? null : dob.toLocalDate());
        patient.setPhone(rs.getString("phone"));
        patient.setEmail(rs.getString("email"));
        patient.setAddress(rs.getString("address"));
        patient.setBloodGroup(rs.getString("blood_group"));
        return patient;
    }

    private void ensureUniquePatient(String phone, String email, Long excludeId) {
        String sql = """
                SELECT id FROM patients
                WHERE (phone = ? OR (email IS NOT NULL AND email = ?))
                """;
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, phone);
            ps.setString(2, email);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long existingId = rs.getLong("id");
                    if (excludeId == null || existingId != excludeId) {
                        throw new IllegalArgumentException("Patient with same phone/email already exists");
                    }
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to validate patient uniqueness", e);
        }
    }

    // ---------------------------
    // Specialty & Doctor Operations
    // ---------------------------
    public long addSpecialty(String name) {
        String sql = "INSERT INTO specialties(name) VALUES (?) RETURNING id";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to add specialty", e);
        }
        throw new IllegalStateException("Failed to add specialty");
    }

    public void updateSpecialty(long id, String name) {
        String sql = "UPDATE specialties SET name = ? WHERE id = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setLong(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to update specialty", e);
        }
    }

    public void deleteSpecialty(long id) {
        String checkSql = "SELECT COUNT(*) FROM doctors WHERE specialty_id = ?";
        String deleteSql = "DELETE FROM specialties WHERE id = ?";
        try (Connection connection = DbUtil.getConnection()) {
            try (PreparedStatement check = connection.prepareStatement(checkSql)) {
                check.setLong(1, id);
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        throw new IllegalArgumentException("Specialty is in use by doctors");
                    }
                }
            }
            try (PreparedStatement delete = connection.prepareStatement(deleteSql)) {
                delete.setLong(1, id);
                delete.executeUpdate();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to delete specialty", e);
        }
    }

    public List<Specialty> listSpecialties() {
        String sql = "SELECT id, name FROM specialties ORDER BY name";
        List<Specialty> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                results.add(new Specialty(rs.getLong("id"), rs.getString("name")));
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to list specialties", e);
        }
        return results;
    }

    public long addDoctor(String name, String contact, BigDecimal fee, long specialtyId, int maxPerSlot) {
        String sql = """
                INSERT INTO doctors(name, contact, consultation_fee, specialty_id, max_patients_per_slot)
                VALUES (?, ?, ?, ?, ?)
                RETURNING id
                """;
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, contact);
            ps.setBigDecimal(3, fee);
            ps.setLong(4, specialtyId);
            ps.setInt(5, maxPerSlot);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to add doctor", e);
        }
        throw new IllegalStateException("Failed to add doctor");
    }

    public void updateDoctorSpecialty(long doctorId, long specialtyId) {
        String sql = "UPDATE doctors SET specialty_id = ? WHERE id = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, specialtyId);
            ps.setLong(2, doctorId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to update doctor specialty", e);
        }
    }

    public List<DoctorView> viewDoctorsBySpecialty(String specialtyName) {
        String sql = """
                SELECT d.id,
                       d.name,
                       s.name AS specialty,
                       d.consultation_fee,
                       d.is_active,
                       COUNT(a.id) AS todays_appointments
                FROM doctors d
                JOIN specialties s ON d.specialty_id = s.id
                LEFT JOIN appointments a
                  ON a.doctor_id = d.id
                 AND a.appointment_date = CURRENT_DATE
                 AND a.status = 'SCHEDULED'
                WHERE s.name ILIKE ?
                GROUP BY d.id, s.name
                ORDER BY d.name
                """;
        List<DoctorView> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, "%" + specialtyName + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(new DoctorView(
                            rs.getLong("id"),
                            rs.getString("name"),
                            rs.getString("specialty"),
                            rs.getBigDecimal("consultation_fee"),
                            rs.getBoolean("is_active"),
                            rs.getInt("todays_appointments")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to view doctors by specialty", e);
        }
        return results;
    }

    public void deactivateDoctor(long doctorId) {
        String checkSql = """
                SELECT COUNT(*) FROM appointments
                WHERE doctor_id = ? AND appointment_date >= CURRENT_DATE AND status = 'SCHEDULED'
                """;
        String updateSql = "UPDATE doctors SET is_active = false WHERE id = ?";
        try (Connection connection = DbUtil.getConnection()) {
            try (PreparedStatement check = connection.prepareStatement(checkSql)) {
                check.setLong(1, doctorId);
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        throw new IllegalArgumentException("Doctor has future appointments");
                    }
                }
            }
            try (PreparedStatement ps = connection.prepareStatement(updateSql)) {
                ps.setLong(1, doctorId);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to deactivate doctor", e);
        }
    }

    // ---------------------------
    // Appointment Operations
    // ---------------------------
    public long bookAppointment(long patientId, long doctorId, LocalDate date, LocalTime time) {
        requireExists("patients", patientId, "Patient not found");
        requireExists("doctors", doctorId, "Doctor not found");
        int capacity = getDoctorSlotCapacity(doctorId);
        int current = countAppointments(doctorId, date, time);
        if (current >= capacity) {
            throw new IllegalArgumentException("Selected slot is fully booked");
        }
        String sql = """
                INSERT INTO appointments(patient_id, doctor_id, appointment_date, appointment_time, status)
                VALUES (?, ?, ?, ?, 'SCHEDULED')
                RETURNING id
                """;
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, patientId);
            ps.setLong(2, doctorId);
            ps.setDate(3, Date.valueOf(date));
            ps.setTime(4, Time.valueOf(time));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to book appointment", e);
        }
        throw new IllegalStateException("Failed to book appointment");
    }

    public List<AvailabilitySlot> checkDoctorAvailability(long doctorId, LocalDate date) {
        String sql = """
                SELECT appointment_time, COUNT(*) AS cnt
                FROM appointments
                WHERE doctor_id = ? AND appointment_date = ? AND status = 'SCHEDULED'
                GROUP BY appointment_time
                ORDER BY appointment_time
                """;
        int capacity = getDoctorSlotCapacity(doctorId);
        List<AvailabilitySlot> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, doctorId);
            ps.setDate(2, Date.valueOf(date));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Time time = rs.getTime("appointment_time");
                    int count = rs.getInt("cnt");
                    results.add(new AvailabilitySlot(time.toLocalTime(), count, capacity));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to check availability", e);
        }
        return results;
    }

    public void cancelAppointment(long appointmentId, String changedBy) {
        String fetch = "SELECT status FROM appointments WHERE id = ?";
        String update = "UPDATE appointments SET status = 'CANCELLED' WHERE id = ?";
        String audit = """
                INSERT INTO appointment_audit(appointment_id, old_status, new_status, changed_by)
                VALUES (?, ?, ?, ?)
                """;
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            connection.setAutoCommit(false);
            String oldStatus;
            try (PreparedStatement ps = connection.prepareStatement(fetch)) {
                ps.setLong(1, appointmentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new IllegalArgumentException("Appointment not found");
                    }
                    oldStatus = rs.getString("status");
                }
            }
            try (PreparedStatement ps = connection.prepareStatement(update)) {
                ps.setLong(1, appointmentId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement(audit)) {
                ps.setLong(1, appointmentId);
                ps.setString(2, oldStatus);
                ps.setString(3, "CANCELLED");
                ps.setString(4, changedBy);
                ps.executeUpdate();
            }
            connection.commit();
        } catch (SQLException e) {
            rollbackQuietly(connection);
            throw new IllegalStateException("Failed to cancel appointment", e);
        } finally {
            closeQuietly(connection);
        }
    }

    public void rescheduleAppointment(long appointmentId, long doctorId, LocalDate newDate, LocalTime newTime) {
        int capacity = getDoctorSlotCapacity(doctorId);
        int current = countAppointments(doctorId, newDate, newTime);
        if (current >= capacity) {
            throw new IllegalArgumentException("Selected slot is fully booked");
        }
        String sql = """
                UPDATE appointments
                SET doctor_id = ?, appointment_date = ?, appointment_time = ?
                WHERE id = ?
                """;
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setLong(1, doctorId);
                ps.setDate(2, Date.valueOf(newDate));
                ps.setTime(3, Time.valueOf(newTime));
                ps.setLong(4, appointmentId);
                ps.executeUpdate();
            }
            connection.commit();
        } catch (SQLException e) {
            rollbackQuietly(connection);
            throw new IllegalStateException("Failed to reschedule appointment", e);
        } finally {
            closeQuietly(connection);
        }
    }

    public List<DailyScheduleEntry> viewDailySchedule(LocalDate date) {
        String sql = """
                SELECT a.id, a.appointment_time, p.name AS patient_name, d.name AS doctor_name, a.status
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                JOIN doctors d ON a.doctor_id = d.id
                WHERE a.appointment_date = ?
                ORDER BY a.appointment_time
                """;
        List<DailyScheduleEntry> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(new DailyScheduleEntry(
                            rs.getLong("id"),
                            rs.getTime("appointment_time").toLocalTime(),
                            rs.getString("patient_name"),
                            rs.getString("doctor_name"),
                            rs.getString("status")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to view daily schedule", e);
        }
        return results;
    }

    private int countAppointments(long doctorId, LocalDate date, LocalTime time) {
        String sql = """
                SELECT COUNT(*) FROM appointments
                WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ? AND status = 'SCHEDULED'
                """;
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, doctorId);
            ps.setDate(2, Date.valueOf(date));
            ps.setTime(3, Time.valueOf(time));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to check slot capacity", e);
        }
        return 0;
    }

    private int getDoctorSlotCapacity(long doctorId) {
        String sql = "SELECT max_patients_per_slot, is_active FROM doctors WHERE id = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, doctorId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    if (!rs.getBoolean("is_active")) {
                        throw new IllegalArgumentException("Doctor is inactive");
                    }
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to get doctor capacity", e);
        }
        return 1;
    }

    // ---------------------------
    // Visit & Prescription Operations
    // ---------------------------
    public long recordVisit(long appointmentId, long patientId, long doctorId, String diagnosis, String notes) {
        requireExists("appointments", appointmentId, "Appointment not found");
        requireExists("patients", patientId, "Patient not found");
        requireExists("doctors", doctorId, "Doctor not found");
        String visitSql = """
                INSERT INTO visits(appointment_id, patient_id, doctor_id, visit_date, diagnosis, notes)
                VALUES (?, ?, ?, CURRENT_DATE, ?, ?)
                RETURNING id
                """;
        String updateAppointment = "UPDATE appointments SET status = 'COMPLETED' WHERE id = ?";
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            connection.setAutoCommit(false);
            long visitId;
            try (PreparedStatement ps = connection.prepareStatement(visitSql)) {
                ps.setLong(1, appointmentId);
                ps.setLong(2, patientId);
                ps.setLong(3, doctorId);
                ps.setString(4, diagnosis);
                ps.setString(5, notes);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        visitId = rs.getLong(1);
                    } else {
                        throw new IllegalStateException("Failed to record visit");
                    }
                }
            }
            try (PreparedStatement ps = connection.prepareStatement(updateAppointment)) {
                ps.setLong(1, appointmentId);
                ps.executeUpdate();
            }
            connection.commit();
            return visitId;
        } catch (SQLException e) {
            rollbackQuietly(connection);
            throw new IllegalStateException("Failed to record visit", e);
        } finally {
            closeQuietly(connection);
        }
    }

    public void addPrescriptions(long visitId, List<Prescription> prescriptions) {
        String sql = """
                INSERT INTO prescriptions(visit_id, medicine_name, dosage, duration, instructions)
                VALUES (?, ?, ?, ?, ?)
                """;
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            for (Prescription p : prescriptions) {
                ps.setLong(1, visitId);
                ps.setString(2, p.getMedicineName());
                ps.setString(3, p.getDosage());
                ps.setString(4, p.getDuration());
                ps.setString(5, p.getInstructions());
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to add prescriptions", e);
        }
    }

    public List<PatientVisitHistoryEntry> viewPatientVisitHistory(long patientId) {
        String sql = """
                SELECT a.appointment_date,
                       a.appointment_time,
                       v.visit_date,
                       d.name AS doctor_name,
                       v.diagnosis
                FROM visits v
                JOIN appointments a ON v.appointment_id = a.id
                JOIN doctors d ON v.doctor_id = d.id
                WHERE v.patient_id = ?
                ORDER BY v.visit_date
                """;
        List<PatientVisitHistoryEntry> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, patientId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(new PatientVisitHistoryEntry(
                            rs.getDate("visit_date").toLocalDate(),
                            rs.getDate("appointment_date").toLocalDate(),
                            rs.getTime("appointment_time").toLocalTime(),
                            rs.getString("doctor_name"),
                            rs.getString("diagnosis")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to view visit history", e);
        }
        return results;
    }

    public List<MedicalHistoryEntry> viewPatientMedicalHistory(long patientId) {
        String sql = """
                SELECT v.visit_date,
                       a.appointment_date,
                       a.appointment_time,
                       v.diagnosis,
                       p.medicine_name,
                       p.dosage,
                       p.duration
                FROM visits v
                JOIN appointments a ON v.appointment_id = a.id
                LEFT JOIN prescriptions p ON v.id = p.visit_id
                WHERE v.patient_id = ?
                ORDER BY v.visit_date DESC
                """;
        List<MedicalHistoryEntry> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, patientId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(new MedicalHistoryEntry(
                            rs.getDate("visit_date").toLocalDate(),
                            rs.getDate("appointment_date").toLocalDate(),
                            rs.getTime("appointment_time").toLocalTime(),
                            rs.getString("diagnosis"),
                            rs.getString("medicine_name"),
                            rs.getString("dosage"),
                            rs.getString("duration")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to view medical history", e);
        }
        return results;
    }

    // ---------------------------
    // Billing & Payments
    // ---------------------------
    public long generateBill(long visitId, long patientId, long doctorId, List<BillItem> items) {
        requireExists("visits", visitId, "Visit not found");
        requireExists("patients", patientId, "Patient not found");
        requireExists("doctors", doctorId, "Doctor not found");
        String feeSql = "SELECT consultation_fee FROM doctors WHERE id = ?";
        String billSql = """
                INSERT INTO bills(visit_id, patient_id, doctor_id, total_amount, payment_status)
                VALUES (?, ?, ?, ?, 'UNPAID')
                RETURNING id
                """;
        String itemSql = "INSERT INTO bill_items(bill_id, description, amount) VALUES (?, ?, ?)";
        BigDecimal consultationFee = null;
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(feeSql)) {
                ps.setLong(1, doctorId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        consultationFee = rs.getBigDecimal(1);
                    }
                }
            }
            if (consultationFee == null) {
                throw new IllegalArgumentException("Doctor not found for billing");
            }

            BigDecimal total = consultationFee;
            for (BillItem item : items) {
                total = total.add(item.getAmount());
            }

            long billId;
            try (PreparedStatement ps = connection.prepareStatement(billSql)) {
                ps.setLong(1, visitId);
                ps.setLong(2, patientId);
                ps.setLong(3, doctorId);
                ps.setBigDecimal(4, total);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        billId = rs.getLong(1);
                    } else {
                        throw new IllegalStateException("Failed to create bill");
                    }
                }
            }

            try (PreparedStatement ps = connection.prepareStatement(itemSql)) {
                ps.setLong(1, billId);
                ps.setString(2, "Consultation Fee");
                ps.setBigDecimal(3, consultationFee);
                ps.addBatch();
                for (BillItem item : items) {
                    ps.setLong(1, billId);
                    ps.setString(2, item.getDescription());
                    ps.setBigDecimal(3, item.getAmount());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            connection.commit();
            return billId;
        } catch (SQLException e) {
            rollbackQuietly(connection);
            throw new IllegalStateException("Failed to generate bill", e);
        } finally {
            closeQuietly(connection);
        }
    }

    public void recordPayment(long billId, BigDecimal amount, String mode) {
        requireExists("bills", billId, "Bill not found");
        String updateSql = "UPDATE bills SET payment_status = 'PAID' WHERE id = ?";
        String insertSql = """
                INSERT INTO payment_transactions(bill_id, amount, payment_mode)
                VALUES (?, ?, ?)
                """;
        Connection connection = null;
        try {
            connection = DbUtil.getConnection();
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(updateSql)) {
                ps.setLong(1, billId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement(insertSql)) {
                ps.setLong(1, billId);
                ps.setBigDecimal(2, amount);
                ps.setString(3, mode);
                ps.executeUpdate();
            }
            connection.commit();
        } catch (SQLException e) {
            rollbackQuietly(connection);
            throw new IllegalStateException("Failed to record payment", e);
        } finally {
            closeQuietly(connection);
        }
    }

    public List<OutstandingBillSummary> viewOutstandingBills() {
        String sql = """
                SELECT p.name, COUNT(*) AS cnt, SUM(b.total_amount) AS total
                FROM bills b
                JOIN patients p ON b.patient_id = p.id
                WHERE b.payment_status = 'UNPAID'
                GROUP BY p.name
                ORDER BY p.name
                """;
        List<OutstandingBillSummary> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                results.add(new OutstandingBillSummary(
                        rs.getString("name"),
                        rs.getInt("cnt"),
                        rs.getBigDecimal("total")
                ));
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to view outstanding bills", e);
        }
        return results;
    }

    public List<RevenueReportEntry> generateRevenueReport(LocalDate from, LocalDate to) {
        String sql = """
                SELECT d.name AS doctor_name, s.name AS specialty, DATE(b.created_at) AS bill_date, SUM(b.total_amount) AS total
                FROM bills b
                JOIN doctors d ON b.doctor_id = d.id
                JOIN specialties s ON d.specialty_id = s.id
                WHERE DATE(b.created_at) BETWEEN ? AND ?
                GROUP BY d.name, s.name, DATE(b.created_at)
                ORDER BY bill_date
                """;
        List<RevenueReportEntry> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(from));
            ps.setDate(2, Date.valueOf(to));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(new RevenueReportEntry(
                            rs.getDate("bill_date").toLocalDate(),
                            rs.getString("doctor_name"),
                            rs.getString("specialty"),
                            rs.getBigDecimal("total")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to generate revenue report", e);
        }
        return results;
    }

    // ---------------------------
    // Audit Logs & Backup
    // ---------------------------
    public List<AuditLogEntry> viewAuditLogs(String tableName, String action) {
        String sql = """
                SELECT table_name, action, row_id, changed_at, changed_by
                FROM audit_log
                WHERE (? IS NULL OR table_name = ?)
                  AND (? IS NULL OR action = ?)
                ORDER BY changed_at DESC
                """;
        List<AuditLogEntry> results = new ArrayList<>();
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, tableName);
            ps.setString(2, tableName);
            ps.setString(3, action);
            ps.setString(4, action);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(new AuditLogEntry(
                            rs.getString("table_name"),
                            rs.getString("action"),
                            rs.getLong("row_id"),
                            rs.getTimestamp("changed_at").toLocalDateTime(),
                            rs.getString("changed_by")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to view audit logs", e);
        }
        return results;
    }

    public File backupToCsv(String outputDir) {
        File dir = new File(outputDir);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("Failed to create backup directory");
        }
        String timestamp = String.valueOf(System.currentTimeMillis());
        File root = new File(dir, "backup_" + timestamp);
        if (!root.mkdirs()) {
            throw new IllegalStateException("Failed to create backup folder");
        }

        try (Connection connection = DbUtil.getConnection()) {
            DatabaseMetaData meta = connection.getMetaData();
            try (ResultSet tables = meta.getTables(null, "public", "%", new String[]{"TABLE"})) {
                while (tables.next()) {
                    String tableName = tables.getString("TABLE_NAME");
                    dumpTableToCsv(connection, tableName, new File(root, tableName + ".csv"));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to backup database", e);
        }
        return root;
    }

    private void dumpTableToCsv(Connection connection, String tableName, File file) throws SQLException {
        String sql = "SELECT * FROM " + tableName;
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery();
             BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {

            ResultSetMetaData meta = rs.getMetaData();
            int cols = meta.getColumnCount();
            for (int i = 1; i <= cols; i++) {
                writer.write(meta.getColumnName(i));
                if (i < cols) {
                    writer.write(",");
                }
            }
            writer.newLine();

            while (rs.next()) {
                for (int i = 1; i <= cols; i++) {
                    String val = rs.getString(i);
                    writer.write(escapeCsv(val));
                    if (i < cols) {
                        writer.write(",");
                    }
                }
                writer.newLine();
            }
        } catch (Exception e) {
            throw new IllegalStateException("Failed to write CSV for " + tableName, e);
        }
    }

    private String escapeCsv(String value) {
        if (value == null) {
            return "";
        }
        String escaped = value.replace("\"", "\"\"");
        if (escaped.contains(",") || escaped.contains("\"") || escaped.contains("\n")) {
            return "\"" + escaped + "\"";
        }
        return escaped;
    }

    private void requireExists(String table, long id, String message) {
        String sql = "SELECT 1 FROM " + table + " WHERE id = ?";
        try (Connection connection = DbUtil.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new IllegalArgumentException(message);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to validate existence for " + table, e);
        }
    }

    private void rollbackQuietly(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            connection.rollback();
        } catch (SQLException ignored) {
        }
    }

    private void closeQuietly(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            connection.close();
        } catch (SQLException ignored) {
        }
    }
}
