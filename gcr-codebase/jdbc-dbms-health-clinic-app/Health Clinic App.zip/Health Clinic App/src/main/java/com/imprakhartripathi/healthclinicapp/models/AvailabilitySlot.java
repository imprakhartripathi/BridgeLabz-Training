package com.imprakhartripathi.healthclinicapp.models;

import java.time.LocalTime;

public class AvailabilitySlot {
    private LocalTime time;
    private int booked;
    private int capacity;

    public AvailabilitySlot(LocalTime time, int booked, int capacity) {
        this.time = time;
        this.booked = booked;
        this.capacity = capacity;
    }

    public LocalTime getTime() {
        return time;
    }

    public int getBooked() {
        return booked;
    }

    public int getCapacity() {
        return capacity;
    }
}
