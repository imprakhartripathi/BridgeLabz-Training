package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.models.BillItem;
import com.imprakhartripathi.healthclinicapp.models.OutstandingBillSummary;
import com.imprakhartripathi.healthclinicapp.models.RevenueReportEntry;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface BillingService {
    long generateBill(long visitId, long patientId, long doctorId, List<BillItem> items);
    void recordPayment(long billId, BigDecimal amount, String mode);
    List<OutstandingBillSummary> viewOutstandingBills();
    List<RevenueReportEntry> generateRevenueReport(LocalDate from, LocalDate to);
}
