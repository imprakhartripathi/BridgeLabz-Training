package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.Specialty;
import com.imprakhartripathi.healthclinicapp.services.SpecialtyService;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;

import java.util.List;

public class SpecialtyServiceImpl implements SpecialtyService {
    private final DbOperations dbOperations;

    public SpecialtyServiceImpl() {
        this(new DbOperations());
    }

    SpecialtyServiceImpl(DbOperations dbOperations) {
        this.dbOperations = dbOperations;
    }

    @Override
    public List<Specialty> listSpecialties() {
        return dbOperations.listSpecialties();
    }

    @Override
    public long addSpecialty(String name) {
        return dbOperations.addSpecialty(name);
    }

    @Override
    public void updateSpecialty(long id, String name) {
        dbOperations.updateSpecialty(id, name);
    }

    @Override
    public void deleteSpecialty(long id) {
        dbOperations.deleteSpecialty(id);
    }
}
