package com.imprakhartripathi.healthclinicapp;

import com.imprakhartripathi.healthclinicapp.services.AdminService;
import com.imprakhartripathi.healthclinicapp.services.AppointmentService;
import com.imprakhartripathi.healthclinicapp.services.BillingService;
import com.imprakhartripathi.healthclinicapp.services.DoctorService;
import com.imprakhartripathi.healthclinicapp.services.PatientService;
import com.imprakhartripathi.healthclinicapp.services.SpecialtyService;
import com.imprakhartripathi.healthclinicapp.services.VisitService;
import com.imprakhartripathi.healthclinicapp.services.impl.AdminServiceImpl;
import com.imprakhartripathi.healthclinicapp.services.impl.AppointmentServiceImpl;
import com.imprakhartripathi.healthclinicapp.services.impl.BillingServiceImpl;
import com.imprakhartripathi.healthclinicapp.services.impl.DoctorServiceImpl;
import com.imprakhartripathi.healthclinicapp.services.impl.PatientServiceImpl;
import com.imprakhartripathi.healthclinicapp.services.impl.SpecialtyServiceImpl;
import com.imprakhartripathi.healthclinicapp.services.impl.VisitServiceImpl;
import com.imprakhartripathi.healthclinicapp.utils.DbSchemaManager;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class HealthClinicAppApplication implements CommandLineRunner {

    private final PatientService patientService = new PatientServiceImpl();
    private final AppointmentService appointmentService = new AppointmentServiceImpl();
    private final VisitService visitService = new VisitServiceImpl();
    private final BillingService billingService = new BillingServiceImpl();
    private final DoctorService doctorService = new DoctorServiceImpl();
    private final SpecialtyService specialtyService = new SpecialtyServiceImpl();
    private final AdminService adminService = new AdminServiceImpl();
    private final ReceptionConsole receptionConsole =
            new ReceptionConsole(patientService, appointmentService, visitService, billingService);
    private final DoctorConsole doctorConsole =
            new DoctorConsole(appointmentService, visitService);
    private final AdminConsole adminConsole =
            new AdminConsole(doctorService, specialtyService, billingService, adminService);

    public static void main(String[] args) {
        SpringApplication.run(HealthClinicAppApplication.class, args);
    }

    @Override
    public void run(String... args) {

        DbSchemaManager.ensureSchema();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            try {
                System.out.println("\n=== Health Clinic App ===");
                System.out.println("1. Receptionist");
                System.out.println("2. Doctor");
                System.out.println("3. Administrator");
                System.out.println("4. Exit");

                int choice = ConsoleUtils.readInt(scanner, "Select role: ");

                switch (choice) {
                    case 1 -> receptionConsole.run(scanner);
                    case 2 -> doctorConsole.run(scanner);
                    case 3 -> adminConsole.run(scanner);
                    case 4 -> {
                        running = false;
                        System.out.println("Exiting application...");
                    }
                    default -> System.out.println("Invalid option");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid input: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }
}
