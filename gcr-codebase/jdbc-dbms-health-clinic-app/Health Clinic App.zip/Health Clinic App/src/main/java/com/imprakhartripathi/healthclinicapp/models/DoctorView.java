package com.imprakhartripathi.healthclinicapp.models;

import java.math.BigDecimal;

public class DoctorView {
    private long id;
    private String name;
    private String specialtyName;
    private BigDecimal consultationFee;
    private boolean active;
    private int todaysAppointments;

    public DoctorView(long id, String name, String specialtyName, BigDecimal consultationFee,
                      boolean active, int todaysAppointments) {
        this.id = id;
        this.name = name;
        this.specialtyName = specialtyName;
        this.consultationFee = consultationFee;
        this.active = active;
        this.todaysAppointments = todaysAppointments;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSpecialtyName() {
        return specialtyName;
    }

    public BigDecimal getConsultationFee() {
        return consultationFee;
    }

    public boolean isActive() {
        return active;
    }

    public int getTodaysAppointments() {
        return todaysAppointments;
    }
}
