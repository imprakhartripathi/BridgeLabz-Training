package com.imprakhartripathi.healthclinicapp.models;

import java.time.LocalDate;
import java.time.LocalTime;

public class MedicalHistoryEntry {
    private LocalDate visitDate;
    private LocalDate appointmentDate;
    private LocalTime appointmentTime;
    private String diagnosis;
    private String medicineName;
    private String dosage;
    private String duration;

    public MedicalHistoryEntry(LocalDate visitDate, LocalDate appointmentDate, LocalTime appointmentTime,
                               String diagnosis, String medicineName, String dosage, String duration) {
        this.visitDate = visitDate;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.diagnosis = diagnosis;
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.duration = duration;
    }

    public LocalDate getVisitDate() {
        return visitDate;
    }

    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public LocalTime getAppointmentTime() {
        return appointmentTime;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public String getDosage() {
        return dosage;
    }

    public String getDuration() {
        return duration;
    }
}
