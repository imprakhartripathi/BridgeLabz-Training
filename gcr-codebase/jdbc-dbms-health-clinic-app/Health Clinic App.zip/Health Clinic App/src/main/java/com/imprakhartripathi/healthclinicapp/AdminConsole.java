package com.imprakhartripathi.healthclinicapp;

import com.imprakhartripathi.healthclinicapp.models.AuditLogEntry;
import com.imprakhartripathi.healthclinicapp.models.DoctorView;
import com.imprakhartripathi.healthclinicapp.models.RevenueReportEntry;
import com.imprakhartripathi.healthclinicapp.models.Specialty;
import com.imprakhartripathi.healthclinicapp.services.AdminService;
import com.imprakhartripathi.healthclinicapp.services.BillingService;
import com.imprakhartripathi.healthclinicapp.services.DoctorService;
import com.imprakhartripathi.healthclinicapp.services.SpecialtyService;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

final class AdminConsole {
    private final DoctorService doctorService;
    private final SpecialtyService specialtyService;
    private final BillingService billingService;
    private final AdminService adminService;

    AdminConsole(DoctorService doctorService,
                 SpecialtyService specialtyService,
                 BillingService billingService,
                 AdminService adminService) {
        this.doctorService = doctorService;
        this.specialtyService = specialtyService;
        this.billingService = billingService;
        this.adminService = adminService;
    }

    void run(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Administrator Menu ---");
            System.out.println("1. Add Doctor Profile");
            System.out.println("2. Update Doctor Specialty");
            System.out.println("3. View Doctors by Specialty");
            System.out.println("4. Deactivate Doctor Profile");
            System.out.println("5. Manage Specialties");
            System.out.println("6. Generate Revenue Report");
            System.out.println("7. Backup Database to CSV");
            System.out.println("8. View Audit Logs");
            System.out.println("0. Back");

            int choice = ConsoleUtils.readInt(scanner, "Choose option: ");
            switch (choice) {
                case 1 -> addDoctor(scanner);
                case 2 -> updateDoctorSpecialty(scanner);
                case 3 -> viewDoctorsBySpecialty(scanner);
                case 4 -> deactivateDoctor(scanner);
                case 5 -> manageSpecialties(scanner);
                case 6 -> generateRevenueReport(scanner);
                case 7 -> backupDatabase(scanner);
                case 8 -> viewAuditLogs(scanner);
                case 0 -> back = true;
                default -> System.out.println("Invalid option");
            }
        }
    }

    private void addDoctor(Scanner scanner) {
        String name = ConsoleUtils.readNonBlank(scanner, "Enter doctor name: ");
        String contact = ConsoleUtils.readOptional(scanner, "Enter contact (optional): ");
        BigDecimal fee = ConsoleUtils.readDecimal(scanner, "Enter consultation fee: ");
        long specialtyId = ConsoleUtils.readLong(scanner, "Enter specialty ID: ");
        int maxPerSlot = ConsoleUtils.readInt(scanner, "Max patients per slot: ");
        long id = doctorService.addDoctor(name, contact, fee, specialtyId, maxPerSlot);
        System.out.println("Doctor added with ID: " + id);
    }

    private void updateDoctorSpecialty(Scanner scanner) {
        long doctorId = ConsoleUtils.readLong(scanner, "Enter doctor ID: ");
        long specialtyId = ConsoleUtils.readLong(scanner, "Enter new specialty ID: ");
        doctorService.updateDoctorSpecialty(doctorId, specialtyId);
        System.out.println("Doctor specialty updated");
    }

    private void viewDoctorsBySpecialty(Scanner scanner) {
        String name = ConsoleUtils.readNonBlank(scanner, "Enter specialty name: ");
        List<DoctorView> doctors = doctorService.viewDoctorsBySpecialty(name);
        if (doctors.isEmpty()) {
            System.out.println("No doctors found.");
            return;
        }
        System.out.println("ID | Name | Specialty | Fee | Status | Today");
        doctors.forEach(d -> System.out.println(
                d.getId() + " | " + d.getName() + " | " + d.getSpecialtyName() + " | " +
                        d.getConsultationFee() + " | " +
                        (d.isActive() ? "ACTIVE" : "INACTIVE") + " | " +
                        d.getTodaysAppointments()
        ));
    }

    private void deactivateDoctor(Scanner scanner) {
        long doctorId = ConsoleUtils.readLong(scanner, "Enter doctor ID: ");
        doctorService.deactivateDoctor(doctorId);
        System.out.println("Doctor deactivated");
    }

    private void manageSpecialties(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Manage Specialties ---");
            System.out.println("1. List Specialties");
            System.out.println("2. Add Specialty");
            System.out.println("3. Update Specialty");
            System.out.println("4. Delete Specialty");
            System.out.println("0. Back");
            int choice = ConsoleUtils.readInt(scanner, "Choose option: ");
            switch (choice) {
                case 1 -> {
                    List<Specialty> specialties = specialtyService.listSpecialties();
                    if (specialties.isEmpty()) {
                        System.out.println("No specialties found.");
                    } else {
                        System.out.println("ID | Name");
                        specialties.forEach(s -> System.out.println(s.getId() + " | " + s.getName()));
                    }
                }
                case 2 -> {
                    String name = ConsoleUtils.readNonBlank(scanner, "Enter name: ");
                    long id = specialtyService.addSpecialty(name);
                    System.out.println("Specialty added with ID: " + id);
                }
                case 3 -> {
                    long id = ConsoleUtils.readLong(scanner, "Enter specialty ID: ");
                    String name = ConsoleUtils.readNonBlank(scanner, "Enter new name: ");
                    specialtyService.updateSpecialty(id, name);
                    System.out.println("Specialty updated");
                }
                case 4 -> {
                    long id = ConsoleUtils.readLong(scanner, "Enter specialty ID: ");
                    specialtyService.deleteSpecialty(id);
                    System.out.println("Specialty deleted");
                }
                case 0 -> back = true;
                default -> System.out.println("Invalid option");
            }
        }
    }

    private void generateRevenueReport(Scanner scanner) {
        LocalDate from = ConsoleUtils.readDate(scanner, "From date (yyyy-MM-dd): ");
        LocalDate to = ConsoleUtils.readDate(scanner, "To date (yyyy-MM-dd): ");
        List<RevenueReportEntry> report = billingService.generateRevenueReport(from, to);
        if (report.isEmpty()) {
            System.out.println("No revenue data found.");
            return;
        }
        System.out.println("Date | Doctor | Specialty | Total");
        report.forEach(r -> System.out.println(
                r.getBillDate() + " | " + r.getDoctorName() + " | " +
                        r.getSpecialtyName() + " | " + r.getTotal()
        ));
    }

    private void backupDatabase(Scanner scanner) {
        String dir = ConsoleUtils.readOptional(scanner, "Enter backup directory path (default: ./backups): ");
        if (dir == null) {
            dir = "./backups";
        }
        System.out.println("Backup created at: " + adminService.backupToCsv(dir).getAbsolutePath());
    }

    private void viewAuditLogs(Scanner scanner) {
        String table = ConsoleUtils.readOptional(scanner, "Filter by table name (optional): ");
        String action = ConsoleUtils.readOptional(scanner, "Filter by action (optional): ");
        List<AuditLogEntry> logs = adminService.viewAuditLogs(table, action);
        if (logs.isEmpty()) {
            System.out.println("No audit logs found.");
            return;
        }
        System.out.println("Table | Action | Row ID | Time | User");
        logs.forEach(l -> System.out.println(
                l.getTableName() + " | " + l.getAction() + " | " +
                        l.getRowId() + " | " + l.getChangedAt() + " | " +
                        l.getChangedBy()
        ));
    }
}
