package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.models.Specialty;

import java.util.List;

public interface SpecialtyService {
    List<Specialty> listSpecialties();
    long addSpecialty(String name);
    void updateSpecialty(long id, String name);
    void deleteSpecialty(long id);
}
