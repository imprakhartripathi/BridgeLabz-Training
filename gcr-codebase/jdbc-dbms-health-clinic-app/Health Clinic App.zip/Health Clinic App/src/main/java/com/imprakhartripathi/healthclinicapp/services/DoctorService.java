package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.models.DoctorView;

import java.math.BigDecimal;
import java.util.List;

public interface DoctorService {
    long addDoctor(String name, String contact, BigDecimal fee, long specialtyId, int maxPerSlot);
    void updateDoctorSpecialty(long doctorId, long specialtyId);
    List<DoctorView> viewDoctorsBySpecialty(String specialtyName);
    void deactivateDoctor(long doctorId);
}
