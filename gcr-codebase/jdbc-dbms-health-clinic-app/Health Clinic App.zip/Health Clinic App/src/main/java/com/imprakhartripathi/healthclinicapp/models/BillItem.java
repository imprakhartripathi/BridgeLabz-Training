package com.imprakhartripathi.healthclinicapp.models;

import java.math.BigDecimal;

public class BillItem {
    private String description;
    private BigDecimal amount;

    public BillItem(String description, BigDecimal amount) {
        this.description = description;
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public BigDecimal getAmount() {
        return amount;
    }
}
