package com.imprakhartripathi.healthclinicapp.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public final class DbSchemaManager {

    private DbSchemaManager() {
    }

    public static void ensureSchema() {
        try (Connection connection = DbUtil.getConnection()) {
            connection.setAutoCommit(false);
            try (Statement statement = connection.createStatement()) {
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS patients (
                            id BIGSERIAL PRIMARY KEY,
                            name TEXT NOT NULL,
                            dob DATE,
                            phone VARCHAR(30) NOT NULL,
                            email VARCHAR(255),
                            address TEXT,
                            blood_group VARCHAR(10),
                            created_at TIMESTAMP DEFAULT now()
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS specialties (
                            id BIGSERIAL PRIMARY KEY,
                            name TEXT NOT NULL UNIQUE,
                            created_at TIMESTAMP DEFAULT now()
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS doctors (
                            id BIGSERIAL PRIMARY KEY,
                            name TEXT NOT NULL,
                            contact VARCHAR(50),
                            consultation_fee NUMERIC(10,2) NOT NULL,
                            specialty_id BIGINT REFERENCES specialties(id),
                            is_active BOOLEAN DEFAULT true,
                            max_patients_per_slot INT DEFAULT 1,
                            created_at TIMESTAMP DEFAULT now()
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS appointments (
                            id BIGSERIAL PRIMARY KEY,
                            patient_id BIGINT REFERENCES patients(id),
                            doctor_id BIGINT REFERENCES doctors(id),
                            appointment_date DATE NOT NULL,
                            appointment_time TIME NOT NULL,
                            status VARCHAR(20) NOT NULL,
                            created_at TIMESTAMP DEFAULT now()
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS visits (
                            id BIGSERIAL PRIMARY KEY,
                            appointment_id BIGINT REFERENCES appointments(id),
                            patient_id BIGINT REFERENCES patients(id),
                            doctor_id BIGINT REFERENCES doctors(id),
                            visit_date DATE NOT NULL,
                            diagnosis TEXT,
                            notes TEXT,
                            created_at TIMESTAMP DEFAULT now()
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS prescriptions (
                            id BIGSERIAL PRIMARY KEY,
                            visit_id BIGINT REFERENCES visits(id),
                            medicine_name TEXT NOT NULL,
                            dosage TEXT,
                            duration TEXT,
                            instructions TEXT
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS bills (
                            id BIGSERIAL PRIMARY KEY,
                            visit_id BIGINT REFERENCES visits(id),
                            patient_id BIGINT REFERENCES patients(id),
                            doctor_id BIGINT REFERENCES doctors(id),
                            total_amount NUMERIC(10,2) NOT NULL,
                            payment_status VARCHAR(20) NOT NULL,
                            created_at TIMESTAMP DEFAULT now()
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS bill_items (
                            id BIGSERIAL PRIMARY KEY,
                            bill_id BIGINT REFERENCES bills(id) ON DELETE CASCADE,
                            description TEXT NOT NULL,
                            amount NUMERIC(10,2) NOT NULL
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS payment_transactions (
                            id BIGSERIAL PRIMARY KEY,
                            bill_id BIGINT REFERENCES bills(id),
                            amount NUMERIC(10,2) NOT NULL,
                            payment_mode VARCHAR(20) NOT NULL,
                            payment_date TIMESTAMP DEFAULT now()
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS appointment_audit (
                            id BIGSERIAL PRIMARY KEY,
                            appointment_id BIGINT,
                            old_status VARCHAR(20),
                            new_status VARCHAR(20),
                            changed_at TIMESTAMP DEFAULT now(),
                            changed_by VARCHAR(50)
                        )
                        """);
                statement.addBatch("""
                        CREATE TABLE IF NOT EXISTS audit_log (
                            id BIGSERIAL PRIMARY KEY,
                            table_name TEXT NOT NULL,
                            action TEXT NOT NULL,
                            row_id BIGINT,
                            changed_at TIMESTAMP DEFAULT now(),
                            changed_by TEXT,
                            old_data JSONB,
                            new_data JSONB
                        )
                        """);
                statement.addBatch("""
                        ALTER TABLE patients ADD COLUMN IF NOT EXISTS dob DATE
                        """);
                statement.addBatch("""
                        ALTER TABLE patients ADD COLUMN IF NOT EXISTS email VARCHAR(255)
                        """);
                statement.addBatch("""
                        ALTER TABLE patients ADD COLUMN IF NOT EXISTS address TEXT
                        """);
                statement.addBatch("""
                        ALTER TABLE patients ADD COLUMN IF NOT EXISTS blood_group VARCHAR(10)
                        """);
                statement.addBatch("""
                        CREATE INDEX IF NOT EXISTS idx_patients_phone ON patients(phone)
                        """);
                statement.addBatch("""
                        CREATE INDEX IF NOT EXISTS idx_patients_email ON patients(email)
                        """);
                statement.addBatch("""
                        CREATE INDEX IF NOT EXISTS idx_appointments_doctor_date ON appointments(doctor_id, appointment_date)
                        """);
                statement.addBatch("""
                        CREATE INDEX IF NOT EXISTS idx_appointments_patient_date ON appointments(patient_id, appointment_date)
                        """);
                statement.addBatch("""
                        CREATE INDEX IF NOT EXISTS idx_visits_patient_date ON visits(patient_id, visit_date)
                        """);
                statement.executeBatch();
            }

            try (Statement statement = connection.createStatement()) {
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (
                                SELECT 1 FROM pg_constraint WHERE conname = 'uk_patients_phone'
                            ) THEN
                                ALTER TABLE patients ADD CONSTRAINT uk_patients_phone UNIQUE (phone);
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (
                                SELECT 1 FROM pg_constraint WHERE conname = 'uk_patients_email'
                            ) THEN
                                ALTER TABLE patients ADD CONSTRAINT uk_patients_email UNIQUE (email);
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        CREATE OR REPLACE FUNCTION audit_changes() RETURNS trigger AS $$
                        BEGIN
                            IF (TG_OP = 'DELETE') THEN
                                INSERT INTO audit_log(table_name, action, row_id, changed_by, old_data)
                                VALUES (TG_TABLE_NAME, TG_OP, OLD.id, current_user, to_jsonb(OLD));
                                RETURN OLD;
                            ELSIF (TG_OP = 'UPDATE') THEN
                                INSERT INTO audit_log(table_name, action, row_id, changed_by, old_data, new_data)
                                VALUES (TG_TABLE_NAME, TG_OP, NEW.id, current_user, to_jsonb(OLD), to_jsonb(NEW));
                                RETURN NEW;
                            ELSE
                                INSERT INTO audit_log(table_name, action, row_id, changed_by, new_data)
                                VALUES (TG_TABLE_NAME, TG_OP, NEW.id, current_user, to_jsonb(NEW));
                                RETURN NEW;
                            END IF;
                        END;
                        $$ LANGUAGE plpgsql;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'audit_patients') THEN
                                CREATE TRIGGER audit_patients
                                AFTER INSERT OR UPDATE OR DELETE ON patients
                                FOR EACH ROW EXECUTE FUNCTION audit_changes();
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'audit_doctors') THEN
                                CREATE TRIGGER audit_doctors
                                AFTER INSERT OR UPDATE OR DELETE ON doctors
                                FOR EACH ROW EXECUTE FUNCTION audit_changes();
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'audit_appointments') THEN
                                CREATE TRIGGER audit_appointments
                                AFTER INSERT OR UPDATE OR DELETE ON appointments
                                FOR EACH ROW EXECUTE FUNCTION audit_changes();
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'audit_visits') THEN
                                CREATE TRIGGER audit_visits
                                AFTER INSERT OR UPDATE OR DELETE ON visits
                                FOR EACH ROW EXECUTE FUNCTION audit_changes();
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'audit_prescriptions') THEN
                                CREATE TRIGGER audit_prescriptions
                                AFTER INSERT OR UPDATE OR DELETE ON prescriptions
                                FOR EACH ROW EXECUTE FUNCTION audit_changes();
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'audit_bills') THEN
                                CREATE TRIGGER audit_bills
                                AFTER INSERT OR UPDATE OR DELETE ON bills
                                FOR EACH ROW EXECUTE FUNCTION audit_changes();
                            END IF;
                        END $$;
                        """);
                statement.execute("""
                        DO $$ BEGIN
                            IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'audit_specialties') THEN
                                CREATE TRIGGER audit_specialties
                                AFTER INSERT OR UPDATE OR DELETE ON specialties
                                FOR EACH ROW EXECUTE FUNCTION audit_changes();
                            END IF;
                        END $$;
                        """);
            }

            connection.commit();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to initialize database schema", e);
        }
    }
}
