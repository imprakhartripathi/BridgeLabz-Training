package com.imprakhartripathi.healthclinicapp.utils;

import org.junit.jupiter.api.Test;

import java.sql.Connection;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class DbUtilTest {
    @Test
    void shouldCreateDatabaseConnection() throws Exception {
        try (Connection connection = DbUtil.getConnection()) {
            assertNotNull(connection);
            assertFalse(connection.isClosed());
        }
    }
}
