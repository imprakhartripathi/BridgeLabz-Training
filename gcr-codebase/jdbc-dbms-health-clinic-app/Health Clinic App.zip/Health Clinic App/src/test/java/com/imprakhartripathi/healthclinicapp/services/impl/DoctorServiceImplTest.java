package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.DoctorView;
import com.imprakhartripathi.healthclinicapp.testsupport.FakeDbOperations;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DoctorServiceImplTest {

    @Test
    void shouldDelegateDoctorOperations() {
        FakeDbOperations fake = new FakeDbOperations();
        fake.returnLong = 42L;
        fake.doctorViews = List.of(new DoctorView(1, "D1", "Cardio", BigDecimal.TEN, true, 2));

        DoctorServiceImpl service = new DoctorServiceImpl(fake);
        long id = service.addDoctor("Dr A", "123", BigDecimal.ONE, 9L, 3);

        assertEquals(42L, id);
        assertEquals("Dr A", fake.lastStringA);
        assertEquals("123", fake.lastStringB);
        assertEquals(BigDecimal.ONE, fake.lastDecimal);
        assertEquals(9L, fake.lastLongA);
        assertEquals(3L, fake.lastLongB);

        service.updateDoctorSpecialty(7L, 8L);
        assertEquals(7L, fake.lastLongA);
        assertEquals(8L, fake.lastLongB);

        List<DoctorView> views = service.viewDoctorsBySpecialty("cardio");
        assertEquals(1, views.size());
        assertEquals("cardio", fake.lastStringA);

        service.deactivateDoctor(99L);
        assertEquals(99L, fake.lastLongA);
    }
}
