package com.imprakhartripathi.healthclinicapp.testsupport;

import com.imprakhartripathi.healthclinicapp.models.AuditLogEntry;
import com.imprakhartripathi.healthclinicapp.models.AvailabilitySlot;
import com.imprakhartripathi.healthclinicapp.models.BillItem;
import com.imprakhartripathi.healthclinicapp.models.DailyScheduleEntry;
import com.imprakhartripathi.healthclinicapp.models.DoctorView;
import com.imprakhartripathi.healthclinicapp.models.MedicalHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.OutstandingBillSummary;
import com.imprakhartripathi.healthclinicapp.models.PatientVisitHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.Prescription;
import com.imprakhartripathi.healthclinicapp.models.RevenueReportEntry;
import com.imprakhartripathi.healthclinicapp.models.Specialty;
import com.imprakhartripathi.healthclinicapp.utils.DbOperations;

import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;
import java.util.List;

public class FakeDbOperations extends DbOperations {
    public long lastLongA;
    public long lastLongB;
    public long lastLongC;
    public String lastStringA;
    public String lastStringB;
    public LocalDate lastDate;
    public LocalDate lastDateB;
    public LocalTime lastTime;
    public BigDecimal lastDecimal;
    public List<BillItem> lastBillItems;
    public List<Prescription> lastPrescriptions;
    public List<AvailabilitySlot> availabilitySlots = Collections.emptyList();
    public List<DailyScheduleEntry> dailySchedule = Collections.emptyList();
    public List<DoctorView> doctorViews = Collections.emptyList();
    public List<Specialty> specialties = Collections.emptyList();
    public List<PatientVisitHistoryEntry> visitHistory = Collections.emptyList();
    public List<MedicalHistoryEntry> medicalHistory = Collections.emptyList();
    public List<OutstandingBillSummary> outstandingBills = Collections.emptyList();
    public List<RevenueReportEntry> revenueReport = Collections.emptyList();
    public List<AuditLogEntry> auditLogs = Collections.emptyList();
    public long returnLong = 1L;
    public File returnFile = new File("backup");

    @Override
    public long addDoctor(String name, String contact, BigDecimal fee, long specialtyId, int maxPerSlot) {
        this.lastStringA = name;
        this.lastStringB = contact;
        this.lastDecimal = fee;
        this.lastLongA = specialtyId;
        this.lastLongB = maxPerSlot;
        return returnLong;
    }

    @Override
    public void updateDoctorSpecialty(long doctorId, long specialtyId) {
        this.lastLongA = doctorId;
        this.lastLongB = specialtyId;
    }

    @Override
    public List<DoctorView> viewDoctorsBySpecialty(String specialtyName) {
        this.lastStringA = specialtyName;
        return doctorViews;
    }

    @Override
    public void deactivateDoctor(long doctorId) {
        this.lastLongA = doctorId;
    }

    @Override
    public List<Specialty> listSpecialties() {
        return specialties;
    }

    @Override
    public long addSpecialty(String name) {
        this.lastStringA = name;
        return returnLong;
    }

    @Override
    public void updateSpecialty(long id, String name) {
        this.lastLongA = id;
        this.lastStringA = name;
    }

    @Override
    public void deleteSpecialty(long id) {
        this.lastLongA = id;
    }

    @Override
    public long bookAppointment(long patientId, long doctorId, LocalDate date, LocalTime time) {
        this.lastLongA = patientId;
        this.lastLongB = doctorId;
        this.lastDate = date;
        this.lastTime = time;
        return returnLong;
    }

    @Override
    public List<AvailabilitySlot> checkDoctorAvailability(long doctorId, LocalDate date) {
        this.lastLongA = doctorId;
        this.lastDate = date;
        return availabilitySlots;
    }

    @Override
    public void cancelAppointment(long appointmentId, String changedBy) {
        this.lastLongA = appointmentId;
        this.lastStringA = changedBy;
    }

    @Override
    public void rescheduleAppointment(long appointmentId, long doctorId, LocalDate newDate, LocalTime newTime) {
        this.lastLongA = appointmentId;
        this.lastLongB = doctorId;
        this.lastDate = newDate;
        this.lastTime = newTime;
    }

    @Override
    public List<DailyScheduleEntry> viewDailySchedule(LocalDate date) {
        this.lastDate = date;
        return dailySchedule;
    }

    @Override
    public long recordVisit(long appointmentId, long patientId, long doctorId, String diagnosis, String notes) {
        this.lastLongA = appointmentId;
        this.lastLongB = patientId;
        this.lastLongC = doctorId;
        this.lastStringA = diagnosis;
        this.lastStringB = notes;
        return returnLong;
    }

    @Override
    public void addPrescriptions(long visitId, List<Prescription> prescriptions) {
        this.lastLongA = visitId;
        this.lastPrescriptions = prescriptions;
    }

    @Override
    public List<PatientVisitHistoryEntry> viewPatientVisitHistory(long patientId) {
        this.lastLongA = patientId;
        return visitHistory;
    }

    @Override
    public List<MedicalHistoryEntry> viewPatientMedicalHistory(long patientId) {
        this.lastLongA = patientId;
        return medicalHistory;
    }

    @Override
    public long generateBill(long visitId, long patientId, long doctorId, List<BillItem> items) {
        this.lastLongA = visitId;
        this.lastLongB = patientId;
        this.lastLongC = doctorId;
        this.lastBillItems = items;
        return returnLong;
    }

    @Override
    public void recordPayment(long billId, BigDecimal amount, String mode) {
        this.lastLongA = billId;
        this.lastDecimal = amount;
        this.lastStringA = mode;
    }

    @Override
    public List<OutstandingBillSummary> viewOutstandingBills() {
        return outstandingBills;
    }

    @Override
    public List<RevenueReportEntry> generateRevenueReport(LocalDate from, LocalDate to) {
        this.lastDate = from;
        this.lastDateB = to;
        return revenueReport;
    }

    @Override
    public List<AuditLogEntry> viewAuditLogs(String tableName, String action) {
        this.lastStringA = tableName;
        this.lastStringB = action;
        return auditLogs;
    }

    @Override
    public File backupToCsv(String outputDir) {
        this.lastStringA = outputDir;
        return returnFile;
    }
}
