package com.imprakhartripathi.healthclinicapp.services;

import com.imprakhartripathi.healthclinicapp.dao.PatientDao;
import com.imprakhartripathi.healthclinicapp.models.Patient;
import com.imprakhartripathi.healthclinicapp.services.impl.PatientServiceImpl;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PatientServiceImplTest {

    // Fake DAO: no DB, no env vars
    static class FakePatientDao implements PatientDao {
        @Override
        public long save(Patient patient) {
            return 1L;
        }

        @Override
        public void update(long id, Patient patient) {
            // do nothing
        }

        @Override
        public List<Patient> findAll() {
            return List.of();
        }

        @Override
        public Patient findByPhone(String phone) {
            return null;
        }

        @Override
        public Patient findById(long id) {
            return null;
        }

        @Override
        public List<Patient> searchByName(String nameLike) {
            return List.of();
        }
    }

    private final PatientServiceImpl service =
            new PatientServiceImpl(new FakePatientDao());

    @Test
    void shouldThrowExceptionWhenDobIsMissing() {
        Patient patient = new Patient();
        patient.setName("Test");
        patient.setPhone("1111111111");

        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> service.registerPatient(patient));

        assertEquals("DOB is required", exception.getMessage());
    }

    @Test
    void shouldRegisterPatientWhenDobIsValid() {
        Patient patient = new Patient(
                "Valid User",
                LocalDate.of(1998, 1, 1),
                "2222222222",
                "valid@example.com",
                "Street 1",
                "O+"
        );

        assertDoesNotThrow(() -> service.registerPatient(patient));
    }
}
