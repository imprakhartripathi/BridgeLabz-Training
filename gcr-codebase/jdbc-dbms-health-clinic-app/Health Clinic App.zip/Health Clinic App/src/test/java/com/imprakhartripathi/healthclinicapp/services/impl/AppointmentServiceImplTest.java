package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.AvailabilitySlot;
import com.imprakhartripathi.healthclinicapp.models.DailyScheduleEntry;
import com.imprakhartripathi.healthclinicapp.testsupport.FakeDbOperations;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AppointmentServiceImplTest {

    @Test
    void shouldDelegateAppointmentOperations() {
        FakeDbOperations fake = new FakeDbOperations();
        fake.returnLong = 12L;
        fake.availabilitySlots = List.of(new AvailabilitySlot(LocalTime.NOON, 1, 2));
        fake.dailySchedule = List.of(new DailyScheduleEntry(1, LocalTime.NOON, "P", "D", "SCHEDULED"));

        AppointmentServiceImpl service = new AppointmentServiceImpl(fake);
        long id = service.bookAppointment(1L, 2L, LocalDate.of(2024, 1, 1), LocalTime.NOON);
        assertEquals(12L, id);
        assertEquals(1L, fake.lastLongA);
        assertEquals(2L, fake.lastLongB);

        List<AvailabilitySlot> slots = service.checkDoctorAvailability(5L, LocalDate.of(2024, 2, 2));
        assertEquals(1, slots.size());
        assertEquals(5L, fake.lastLongA);

        service.cancelAppointment(9L, "user");
        assertEquals(9L, fake.lastLongA);
        assertEquals("user", fake.lastStringA);

        service.rescheduleAppointment(7L, 8L, LocalDate.of(2024, 3, 3), LocalTime.of(10, 0));
        assertEquals(7L, fake.lastLongA);
        assertEquals(8L, fake.lastLongB);

        List<DailyScheduleEntry> schedule = service.viewDailySchedule(LocalDate.of(2024, 4, 4));
        assertEquals(1, schedule.size());
        assertEquals(LocalDate.of(2024, 4, 4), fake.lastDate);
    }
}
