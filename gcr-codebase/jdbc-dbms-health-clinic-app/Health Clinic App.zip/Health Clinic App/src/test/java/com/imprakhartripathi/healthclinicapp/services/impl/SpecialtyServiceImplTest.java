package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.Specialty;
import com.imprakhartripathi.healthclinicapp.testsupport.FakeDbOperations;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SpecialtyServiceImplTest {

    @Test
    void shouldDelegateSpecialtyOperations() {
        FakeDbOperations fake = new FakeDbOperations();
        fake.specialties = List.of(new Specialty(1, "Cardio"));
        fake.returnLong = 5L;

        SpecialtyServiceImpl service = new SpecialtyServiceImpl(fake);

        List<Specialty> list = service.listSpecialties();
        assertEquals(1, list.size());

        long id = service.addSpecialty("Neuro");
        assertEquals(5L, id);
        assertEquals("Neuro", fake.lastStringA);

        service.updateSpecialty(10L, "Ortho");
        assertEquals(10L, fake.lastLongA);
        assertEquals("Ortho", fake.lastStringA);

        service.deleteSpecialty(11L);
        assertEquals(11L, fake.lastLongA);
    }
}
