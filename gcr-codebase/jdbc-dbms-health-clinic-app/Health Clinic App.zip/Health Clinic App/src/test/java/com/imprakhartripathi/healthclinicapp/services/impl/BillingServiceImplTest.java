package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.BillItem;
import com.imprakhartripathi.healthclinicapp.models.OutstandingBillSummary;
import com.imprakhartripathi.healthclinicapp.models.RevenueReportEntry;
import com.imprakhartripathi.healthclinicapp.testsupport.FakeDbOperations;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BillingServiceImplTest {

    @Test
    void shouldDelegateBillingOperations() {
        FakeDbOperations fake = new FakeDbOperations();
        fake.returnLong = 123L;
        fake.outstandingBills = List.of(new OutstandingBillSummary("P", 1, BigDecimal.TEN));
        fake.revenueReport = List.of(new RevenueReportEntry(LocalDate.of(2024, 1, 1), "D", "S", BigDecimal.ONE));

        BillingServiceImpl service = new BillingServiceImpl(fake);
        List<BillItem> items = List.of(new BillItem("X", BigDecimal.ONE));
        long id = service.generateBill(1L, 2L, 3L, items);
        assertEquals(123L, id);
        assertEquals(1L, fake.lastLongA);
        assertEquals(2L, fake.lastLongB);
        assertEquals(3L, fake.lastLongC);
        assertEquals(1, fake.lastBillItems.size());

        service.recordPayment(9L, BigDecimal.TEN, "CARD");
        assertEquals(9L, fake.lastLongA);
        assertEquals(BigDecimal.TEN, fake.lastDecimal);
        assertEquals("CARD", fake.lastStringA);

        List<OutstandingBillSummary> summaries = service.viewOutstandingBills();
        assertEquals(1, summaries.size());

        List<RevenueReportEntry> report = service.generateRevenueReport(
                LocalDate.of(2024, 1, 1),
                LocalDate.of(2024, 1, 2)
        );
        assertEquals(1, report.size());
        assertEquals(LocalDate.of(2024, 1, 1), fake.lastDate);
        assertEquals(LocalDate.of(2024, 1, 2), fake.lastDateB);
    }
}
