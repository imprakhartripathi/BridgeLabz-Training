package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.AuditLogEntry;
import com.imprakhartripathi.healthclinicapp.testsupport.FakeDbOperations;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AdminServiceImplTest {

    @Test
    void shouldDelegateAdminOperations() {
        FakeDbOperations fake = new FakeDbOperations();
        fake.auditLogs = List.of(new AuditLogEntry("patients", "INSERT", 1L, LocalDateTime.now(), "user"));
        fake.returnFile = new File("backup-dir");

        AdminServiceImpl service = new AdminServiceImpl(fake);

        List<AuditLogEntry> logs = service.viewAuditLogs("patients", "INSERT");
        assertEquals(1, logs.size());
        assertEquals("patients", fake.lastStringA);
        assertEquals("INSERT", fake.lastStringB);

        File file = service.backupToCsv("./backups");
        assertEquals("backup-dir", file.getPath());
        assertEquals("./backups", fake.lastStringA);
    }
}
