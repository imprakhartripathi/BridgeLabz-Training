package com.imprakhartripathi.healthclinicapp;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@Disabled("Context load test disabled to avoid DB execution")
@SpringBootTest
class HealthClinicAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
