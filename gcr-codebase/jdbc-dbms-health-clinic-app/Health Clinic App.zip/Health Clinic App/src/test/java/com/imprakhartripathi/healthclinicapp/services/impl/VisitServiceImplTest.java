package com.imprakhartripathi.healthclinicapp.services.impl;

import com.imprakhartripathi.healthclinicapp.models.MedicalHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.PatientVisitHistoryEntry;
import com.imprakhartripathi.healthclinicapp.models.Prescription;
import com.imprakhartripathi.healthclinicapp.testsupport.FakeDbOperations;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class VisitServiceImplTest {

    @Test
    void shouldDelegateVisitOperations() {
        FakeDbOperations fake = new FakeDbOperations();
        fake.returnLong = 77L;
        fake.visitHistory = List.of(new PatientVisitHistoryEntry(
                LocalDate.of(2024, 1, 1),
                LocalDate.of(2024, 1, 1),
                LocalTime.NOON,
                "Doc",
                "Diag"
        ));
        fake.medicalHistory = List.of(new MedicalHistoryEntry(
                LocalDate.of(2024, 1, 1),
                LocalDate.of(2024, 1, 1),
                LocalTime.NOON,
                "Diag",
                "Med",
                "Dose",
                "Dur"
        ));

        VisitServiceImpl service = new VisitServiceImpl(fake);
        long id = service.recordVisit(1L, 2L, 3L, "d", "n");
        assertEquals(77L, id);
        assertEquals(1L, fake.lastLongA);
        assertEquals(2L, fake.lastLongB);
        assertEquals(3L, fake.lastLongC);

        List<Prescription> prescriptions = List.of(new Prescription(1L, "M", null, null, null));
        service.addPrescriptions(1L, prescriptions);
        assertEquals(1L, fake.lastLongA);
        assertEquals(1, fake.lastPrescriptions.size());

        List<PatientVisitHistoryEntry> history = service.viewPatientVisitHistory(5L);
        assertEquals(1, history.size());
        assertEquals(5L, fake.lastLongA);

        List<MedicalHistoryEntry> med = service.viewPatientMedicalHistory(6L);
        assertEquals(1, med.size());
        assertEquals(6L, fake.lastLongA);
    }
}
