package com.imprakhartripathi;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BankDemoTest {

    private BankDemo account;

    @BeforeEach
    void setUp() {
        account = new BankDemo(1000.0);
    }

    @Test
    void Test_Deposit_ValidAmount() {
        account.deposit(500.0);
        assertEquals(1500.0, account.getBalance());
    }

    @Test
    void Test_Deposit_NegativeAmount() {
        Exception exception = assertThrows(IllegalArgumentException.class,
                () -> account.deposit(-100.0));

        assertEquals("Deposit amount cannot be negative", exception.getMessage());
    }

    @Test
    void Test_Withdraw_ValidAmount() {
        account.withdraw(400.0);
        assertEquals(600.0, account.getBalance());
    }

    @Test
    void Test_Withdraw_InsufficientFunds() {
        Exception exception = assertThrows(IllegalArgumentException.class,
                () -> account.withdraw(2000.0));

        assertEquals("Insufficient funds.", exception.getMessage());
    }
}
