package com.imprakhartripathi.junitdemo.util;

public class NumberUtils {

    public boolean isEven(int number) {
        return number % 2 == 0;
    }
}
