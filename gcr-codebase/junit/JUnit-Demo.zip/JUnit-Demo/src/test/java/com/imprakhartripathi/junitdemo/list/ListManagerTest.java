package com.imprakhartripathi.junitdemo.list;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ListManagerTest {

    ListManager manager = new ListManager();

    @Test
    void testAddAndSize() {
        List<Integer> list = new ArrayList<>();
        manager.addElement(list, 10);
        assertEquals(1, manager.getSize(list));
    }

    @Test
    void testRemove() {
        List<Integer> list = new ArrayList<>();
        list.add(5);
        manager.removeElement(list, 5);
        assertEquals(0, manager.getSize(list));
    }
}
