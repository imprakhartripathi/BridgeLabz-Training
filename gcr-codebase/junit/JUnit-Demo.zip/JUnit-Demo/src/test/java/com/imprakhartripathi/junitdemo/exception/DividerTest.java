package com.imprakhartripathi.junitdemo.exception;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DividerTest {

    Divider divider = new Divider();

    @Test
    void shouldDivideNormally() {
        assertEquals(5, divider.divide(10, 2));
    }

    @Test
    void shouldThrowExceptionWhenDividingByZero() {
        ArithmeticException ex = assertThrows(
                ArithmeticException.class,
                () -> divider.divide(10, 0)
        );

        assertEquals("Cannot divide by zero", ex.getMessage());
    }
}
