package com.imprakhartripathi.employeewage.repository;

import com.imprakhartripathi.employeewage.domain.CompanyEmpWage;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class InMemoryCompanyRepository implements CompanyRepository {
    private final Map<String, CompanyEmpWage> companiesByName = new LinkedHashMap<>();

    @Override
    public void add(CompanyEmpWage company) {
        companiesByName.put(company.getCompanyName(), company);
    }

    @Override
    public Optional<CompanyEmpWage> findByName(String companyName) {
        return Optional.ofNullable(companiesByName.get(companyName));
    }

    @Override
    public List<CompanyEmpWage> findAll() {
        return new ArrayList<>(companiesByName.values());
    }
}
