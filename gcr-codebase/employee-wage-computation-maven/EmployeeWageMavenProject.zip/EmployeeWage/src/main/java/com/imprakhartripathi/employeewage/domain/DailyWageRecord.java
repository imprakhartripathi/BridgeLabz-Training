package com.imprakhartripathi.employeewage.domain;

public final class DailyWageRecord {
    private final int day;
    private final int hoursWorked;
    private final int dailyWage;
    private final EmployeeType employeeType;

    public DailyWageRecord(int day, int hoursWorked, int dailyWage, EmployeeType employeeType) {
        this.day = day;
        this.hoursWorked = hoursWorked;
        this.dailyWage = dailyWage;
        this.employeeType = employeeType;
    }

    public int getDay() {
        return day;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    public int getDailyWage() {
        return dailyWage;
    }

    public EmployeeType getEmployeeType() {
        return employeeType;
    }
}
