package com.imprakhartripathi.employeewage.repository;

import com.imprakhartripathi.employeewage.domain.CompanyEmpWage;

import java.util.List;
import java.util.Optional;

public interface CompanyRepository {
    void add(CompanyEmpWage company);

    Optional<CompanyEmpWage> findByName(String companyName);

    List<CompanyEmpWage> findAll();
}
