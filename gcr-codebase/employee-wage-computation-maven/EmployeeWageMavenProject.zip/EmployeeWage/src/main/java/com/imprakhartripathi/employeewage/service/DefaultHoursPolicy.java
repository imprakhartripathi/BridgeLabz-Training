package com.imprakhartripathi.employeewage.service;

import com.imprakhartripathi.employeewage.domain.EmployeeType;

import java.util.EnumMap;
import java.util.Map;

public final class DefaultHoursPolicy implements HoursPolicy {
    private final Map<EmployeeType, Integer> hoursByType;

    public DefaultHoursPolicy(int fullTimeHours, int partTimeHours) {
        hoursByType = new EnumMap<>(EmployeeType.class);
        hoursByType.put(EmployeeType.ABSENT, 0);
        hoursByType.put(EmployeeType.FULL_TIME, fullTimeHours);
        hoursByType.put(EmployeeType.PART_TIME, partTimeHours);
    }

    @Override
    public int getHoursFor(EmployeeType employeeType) {
        return hoursByType.getOrDefault(employeeType, 0);
    }
}
