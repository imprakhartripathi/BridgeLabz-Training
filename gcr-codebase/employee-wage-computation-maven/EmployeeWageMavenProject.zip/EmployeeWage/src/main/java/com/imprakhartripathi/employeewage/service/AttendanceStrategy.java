package com.imprakhartripathi.employeewage.service;

import com.imprakhartripathi.employeewage.domain.EmployeeType;

public interface AttendanceStrategy {
    EmployeeType getAttendance();
}
