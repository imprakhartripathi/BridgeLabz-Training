package com.imprakhartripathi.employeewage.service;

import com.imprakhartripathi.employeewage.domain.CompanyEmpWage;

import java.util.List;

public interface EmpWageService {
    void addCompany(CompanyEmpWage company);

    void computeWages();

    int getTotalWageByCompany(String companyName);

    List<CompanyEmpWage> getAllCompanies();
}
