package com.imprakhartripathi.employeewage.service;

public class CompanyNotFoundException extends RuntimeException {
    public CompanyNotFoundException(String companyName) {
        super("Company not found: " + companyName);
    }
}
