package com.imprakhartripathi.employeewage.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class CompanyEmpWage {
    private final String companyName;
    private final int wagePerHour;
    private final int maxWorkingDays;
    private final int maxWorkingHours;
    private int totalWage;
    private final List<DailyWageRecord> dailyWageRecords;

    public CompanyEmpWage(String companyName, int wagePerHour, int maxWorkingDays, int maxWorkingHours) {
        this.companyName = companyName;
        this.wagePerHour = wagePerHour;
        this.maxWorkingDays = maxWorkingDays;
        this.maxWorkingHours = maxWorkingHours;
        this.dailyWageRecords = new ArrayList<>();
    }

    public String getCompanyName() {
        return companyName;
    }

    public int getWagePerHour() {
        return wagePerHour;
    }

    public int getMaxWorkingDays() {
        return maxWorkingDays;
    }

    public int getMaxWorkingHours() {
        return maxWorkingHours;
    }

    public int getTotalWage() {
        return totalWage;
    }

    public void setTotalWage(int totalWage) {
        this.totalWage = totalWage;
    }

    public void addDailyWageRecord(DailyWageRecord record) {
        this.dailyWageRecords.add(record);
    }

    public void clearDailyWageRecords() {
        this.dailyWageRecords.clear();
    }

    public List<DailyWageRecord> getDailyWageRecords() {
        return Collections.unmodifiableList(dailyWageRecords);
    }
}
