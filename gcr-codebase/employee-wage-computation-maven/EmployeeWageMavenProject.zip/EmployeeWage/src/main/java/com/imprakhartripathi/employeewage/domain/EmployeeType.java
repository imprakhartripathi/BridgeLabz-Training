package com.imprakhartripathi.employeewage.domain;

public enum EmployeeType {
    ABSENT,
    FULL_TIME,
    PART_TIME
}
