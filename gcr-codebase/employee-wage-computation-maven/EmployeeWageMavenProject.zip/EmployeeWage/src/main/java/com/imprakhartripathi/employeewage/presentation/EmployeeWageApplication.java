package com.imprakhartripathi.employeewage.presentation;

import com.imprakhartripathi.employeewage.domain.CompanyEmpWage;
import com.imprakhartripathi.employeewage.domain.DailyWageRecord;
import com.imprakhartripathi.employeewage.repository.CompanyRepository;
import com.imprakhartripathi.employeewage.repository.InMemoryCompanyRepository;
import com.imprakhartripathi.employeewage.service.AttendanceStrategy;
import com.imprakhartripathi.employeewage.service.DefaultHoursPolicy;
import com.imprakhartripathi.employeewage.service.EmpWageService;
import com.imprakhartripathi.employeewage.service.EmpWageServiceImpl;
import com.imprakhartripathi.employeewage.service.HoursPolicy;
import com.imprakhartripathi.employeewage.service.RandomAttendanceStrategy;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

public final class EmployeeWageApplication {
    public static void main(String[] args) {
        System.out.println("Welcome to Employee Wage Computation Program");

        CompanyRepository companyRepository = new InMemoryCompanyRepository();
        AttendanceStrategy attendanceStrategy = new RandomAttendanceStrategy(new Random());
        HoursPolicy hoursPolicy = new DefaultHoursPolicy(8, 4);

        EmpWageService empWageService = new EmpWageServiceImpl(
                companyRepository,
                attendanceStrategy,
                hoursPolicy
        );

        try (Scanner scanner = new Scanner(System.in)) {
            boolean useSeedData = promptYesNo(scanner, "Use sample companies? (y/n): ", true);
            if (useSeedData) {
                empWageService.addCompany(new CompanyEmpWage("Acme", 20, 20, 100));
                empWageService.addCompany(new CompanyEmpWage("Globex", 25, 22, 110));
            }

            boolean addMore = promptYesNo(scanner, "Add a company? (y/n): ", !useSeedData);
            while (addMore) {
                CompanyEmpWage company = readCompany(scanner);
                empWageService.addCompany(company);
                addMore = promptYesNo(scanner, "Add another company? (y/n): ", false);
            }
        }

        if (empWageService.getAllCompanies().isEmpty()) {
            System.out.println("No companies configured. Exiting.");
            return;
        }

        empWageService.computeWages();

        printReport(empWageService.getAllCompanies());
    }

    private static void printReport(List<CompanyEmpWage> companies) {
        for (CompanyEmpWage company : companies) {
            System.out.println();
            System.out.println("Company: " + company.getCompanyName());
            System.out.println("Total Wage: " + company.getTotalWage());
            System.out.println("Daily Wages:");

            for (DailyWageRecord record : company.getDailyWageRecords()) {
                System.out.println(
                        "Day " + record.getDay()
                                + " | " + record.getEmployeeType()
                                + " | Hours: " + record.getHoursWorked()
                                + " | Wage: " + record.getDailyWage()
                );
            }
        }
    }

    private static CompanyEmpWage readCompany(Scanner scanner) {
        String name = readNonBlank(scanner, "Company name: ");
        int wagePerHour = readPositiveInt(scanner, "Wage per hour: ");
        int maxWorkingDays = readPositiveInt(scanner, "Max working days per month: ");
        int maxWorkingHours = readPositiveInt(scanner, "Max working hours per month: ");
        return new CompanyEmpWage(name, wagePerHour, maxWorkingDays, maxWorkingHours);
    }

    private static boolean promptYesNo(Scanner scanner, String prompt, boolean defaultValue) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim().toLowerCase();
            if (input.isEmpty()) {
                return defaultValue;
            }
            if ("y".equals(input) || "yes".equals(input)) {
                return true;
            }
            if ("n".equals(input) || "no".equals(input)) {
                return false;
            }
            System.out.println("Please enter y or n.");
        }
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // handled below
            }
            System.out.println("Please enter a positive integer.");
        }
    }

    private static String readNonBlank(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("Value cannot be empty.");
        }
    }
}
