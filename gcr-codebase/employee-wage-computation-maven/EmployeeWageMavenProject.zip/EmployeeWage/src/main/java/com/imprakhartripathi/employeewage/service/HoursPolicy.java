package com.imprakhartripathi.employeewage.service;

import com.imprakhartripathi.employeewage.domain.EmployeeType;

public interface HoursPolicy {
    int getHoursFor(EmployeeType employeeType);
}
