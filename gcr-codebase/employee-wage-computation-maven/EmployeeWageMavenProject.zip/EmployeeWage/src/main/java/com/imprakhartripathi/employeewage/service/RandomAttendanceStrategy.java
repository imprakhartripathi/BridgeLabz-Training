package com.imprakhartripathi.employeewage.service;

import com.imprakhartripathi.employeewage.domain.EmployeeType;

import java.util.Random;

public final class RandomAttendanceStrategy implements AttendanceStrategy {
    private final Random random;

    public RandomAttendanceStrategy(Random random) {
        this.random = random;
    }

    @Override
    public EmployeeType getAttendance() {
        int value = random.nextInt(3);
        switch (value) {
            case 1:
                return EmployeeType.FULL_TIME;
            case 2:
                return EmployeeType.PART_TIME;
            case 0:
            default:
                return EmployeeType.ABSENT;
        }
    }
}
