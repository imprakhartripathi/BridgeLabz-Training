package com.imprakhartripathi.employeewage.service;

import com.imprakhartripathi.employeewage.domain.CompanyEmpWage;
import com.imprakhartripathi.employeewage.domain.DailyWageRecord;
import com.imprakhartripathi.employeewage.domain.EmployeeType;
import com.imprakhartripathi.employeewage.repository.CompanyRepository;

import java.util.List;
import java.util.Objects;

public final class EmpWageServiceImpl implements EmpWageService {
    private final CompanyRepository companyRepository;
    private final AttendanceStrategy attendanceStrategy;
    private final HoursPolicy hoursPolicy;

    public EmpWageServiceImpl(CompanyRepository companyRepository,
                              AttendanceStrategy attendanceStrategy,
                              HoursPolicy hoursPolicy) {
        this.companyRepository = Objects.requireNonNull(companyRepository, "companyRepository");
        this.attendanceStrategy = Objects.requireNonNull(attendanceStrategy, "attendanceStrategy");
        this.hoursPolicy = Objects.requireNonNull(hoursPolicy, "hoursPolicy");
    }

    @Override
    public void addCompany(CompanyEmpWage company) {
        companyRepository.add(Objects.requireNonNull(company, "company"));
    }

    @Override
    public void computeWages() {
        List<CompanyEmpWage> companies = companyRepository.findAll();
        for (CompanyEmpWage company : companies) {
            computeCompanyWage(company);
        }
    }

    @Override
    public int getTotalWageByCompany(String companyName) {
        return companyRepository
                .findByName(companyName)
                .map(CompanyEmpWage::getTotalWage)
                .orElseThrow(() -> new CompanyNotFoundException(companyName));
    }

    @Override
    public List<CompanyEmpWage> getAllCompanies() {
        return companyRepository.findAll();
    }

    private void computeCompanyWage(CompanyEmpWage company) {
        company.setTotalWage(0);
        company.clearDailyWageRecords();

        int totalHours = 0;
        int day = 0;
        int totalWage = 0;

        // Stop when either max working days or max working hours is reached.
        while (day < company.getMaxWorkingDays() && totalHours < company.getMaxWorkingHours()) {
            day++;
            EmployeeType employeeType = attendanceStrategy.getAttendance();
            int hoursWorked = hoursPolicy.getHoursFor(employeeType);

            if (totalHours + hoursWorked > company.getMaxWorkingHours()) {
                hoursWorked = company.getMaxWorkingHours() - totalHours;
            }

            int dailyWage = hoursWorked * company.getWagePerHour();
            totalHours += hoursWorked;
            totalWage += dailyWage;

            company.addDailyWageRecord(new DailyWageRecord(day, hoursWorked, dailyWage, employeeType));
        }

        company.setTotalWage(totalWage);
    }
}
