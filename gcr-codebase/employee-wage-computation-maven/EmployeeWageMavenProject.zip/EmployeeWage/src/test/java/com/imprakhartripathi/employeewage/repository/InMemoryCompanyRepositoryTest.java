package com.imprakhartripathi.employeewage.repository;

import com.imprakhartripathi.employeewage.domain.CompanyEmpWage;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InMemoryCompanyRepositoryTest {

    @Test
    void addAndFindByName() {
        CompanyRepository repository = new InMemoryCompanyRepository();
        CompanyEmpWage company = new CompanyEmpWage("Acme", 20, 20, 100);

        repository.add(company);

        assertTrue(repository.findByName("Acme").isPresent());
        assertEquals(company, repository.findByName("Acme").orElseThrow());
    }

    @Test
    void findAllReturnsCompaniesInInsertionOrder() {
        CompanyRepository repository = new InMemoryCompanyRepository();
        CompanyEmpWage acme = new CompanyEmpWage("Acme", 20, 20, 100);
        CompanyEmpWage globex = new CompanyEmpWage("Globex", 25, 22, 110);

        repository.add(acme);
        repository.add(globex);

        assertEquals(2, repository.findAll().size());
        assertEquals("Acme", repository.findAll().get(0).getCompanyName());
        assertEquals("Globex", repository.findAll().get(1).getCompanyName());
    }
}
