package com.imprakhartripathi.employeewage.service;

import com.imprakhartripathi.employeewage.domain.CompanyEmpWage;
import com.imprakhartripathi.employeewage.domain.EmployeeType;
import com.imprakhartripathi.employeewage.repository.CompanyRepository;
import com.imprakhartripathi.employeewage.repository.InMemoryCompanyRepository;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class EmpWageServiceImplTest {

    @Test
    void computeWagesStopsAtMaxHoursAndStoresDailyRecords() {
        CompanyRepository repository = new InMemoryCompanyRepository();
        AttendanceStrategy attendanceStrategy = new SequenceAttendanceStrategy(
                List.of(EmployeeType.FULL_TIME, EmployeeType.PART_TIME, EmployeeType.FULL_TIME)
        );
        HoursPolicy hoursPolicy = new DefaultHoursPolicy(8, 4);

        EmpWageService service = new EmpWageServiceImpl(repository, attendanceStrategy, hoursPolicy);
        CompanyEmpWage company = new CompanyEmpWage("Acme", 20, 20, 10);
        service.addCompany(company);

        service.computeWages();

        assertEquals(200, service.getTotalWageByCompany("Acme"));
        assertEquals(2, company.getDailyWageRecords().size());
        assertEquals(8, company.getDailyWageRecords().get(0).getHoursWorked());
        assertEquals(2, company.getDailyWageRecords().get(1).getHoursWorked());
    }

    @Test
    void computeWagesStopsAtMaxDays() {
        CompanyRepository repository = new InMemoryCompanyRepository();
        AttendanceStrategy attendanceStrategy = new SequenceAttendanceStrategy(
                List.of(EmployeeType.FULL_TIME, EmployeeType.FULL_TIME)
        );
        HoursPolicy hoursPolicy = new DefaultHoursPolicy(8, 4);

        EmpWageService service = new EmpWageServiceImpl(repository, attendanceStrategy, hoursPolicy);
        CompanyEmpWage company = new CompanyEmpWage("Globex", 20, 1, 200);
        service.addCompany(company);

        service.computeWages();

        assertEquals(160, service.getTotalWageByCompany("Globex"));
        assertEquals(1, company.getDailyWageRecords().size());
    }

    @Test
    void getTotalWageByCompanyThrowsWhenMissing() {
        CompanyRepository repository = new InMemoryCompanyRepository();
        EmpWageService service = new EmpWageServiceImpl(
                repository,
                new SequenceAttendanceStrategy(List.of(EmployeeType.ABSENT)),
                new DefaultHoursPolicy(8, 4)
        );

        assertThrows(CompanyNotFoundException.class, () -> service.getTotalWageByCompany("Missing"));
    }

    private static final class SequenceAttendanceStrategy implements AttendanceStrategy {
        private final List<EmployeeType> sequence;
        private int index;

        private SequenceAttendanceStrategy(List<EmployeeType> sequence) {
            this.sequence = sequence;
        }

        @Override
        public EmployeeType getAttendance() {
            EmployeeType type = sequence.get(index % sequence.size());
            index++;
            return type;
        }
    }
}
