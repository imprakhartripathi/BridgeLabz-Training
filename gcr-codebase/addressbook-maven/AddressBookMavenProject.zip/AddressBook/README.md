# Address Book System

Standalone Java Maven project implementing a 4-layer architecture (Presentation, Service, Repository, Domain) with pluggable persistence strategies and async IO.

## Features
- Multiple address books with unique names
- CRUD for contacts
- Duplicate prevention by first + last name
- Search, grouping, counting across books
- Sorting by name, city, state, zip
- TXT, CSV, JSON, JSON-server, and DB persistence (strategy pattern)
- Asynchronous IO using `CompletableFuture`

## Tech
- Java 21
- Maven
- OpenCSV
- Gson
- H2
- SLF4J + Logback

## Run
```bash
mvn -q -DskipTests compile
mvn -q exec:java -Dexec.mainClass=com.imprakhartripathi.addressbook.presentation.AddressBookApplication
```

## CLI Tips
- Use option `1` to create a new address book and `2` to select it.
- Use option `12` to load sample data quickly.
- Use option `11` to switch persistence strategy at runtime.

## Tests
```bash
mvn -q test
```

## Storage
Data is stored under `data/` by default. For tests or custom paths:
```bash
mvn -q test -Daddressbook.data.dir=/tmp/addressbook-data
```
