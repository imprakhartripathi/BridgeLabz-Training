package com.imprakhartripathi.addressbook.domain;

import java.util.Objects;

public class Contact {
    private final Name name;
    private Address address;
    private PhoneNumber phoneNumber;
    private EmailAddress emailAddress;

    public Contact(Name name, Address address, PhoneNumber phoneNumber, EmailAddress emailAddress) {
        this.name = Objects.requireNonNull(name, "Name is required");
        this.address = Objects.requireNonNull(address, "Address is required");
        this.phoneNumber = Objects.requireNonNull(phoneNumber, "Phone number is required");
        this.emailAddress = Objects.requireNonNull(emailAddress, "Email is required");
    }

    public Name name() {
        return name;
    }

    public Address address() {
        return address;
    }

    public PhoneNumber phoneNumber() {
        return phoneNumber;
    }

    public EmailAddress emailAddress() {
        return emailAddress;
    }

    public void updateAddress(Address address) {
        this.address = Objects.requireNonNull(address, "Address is required");
    }

    public void updatePhone(PhoneNumber phoneNumber) {
        this.phoneNumber = Objects.requireNonNull(phoneNumber, "Phone number is required");
    }

    public void updateEmail(EmailAddress emailAddress) {
        this.emailAddress = Objects.requireNonNull(emailAddress, "Email is required");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contact contact = (Contact) o;
        return name.equals(contact.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return name.fullName() + " | " + address + " | " + phoneNumber + " | " + emailAddress;
    }
}
