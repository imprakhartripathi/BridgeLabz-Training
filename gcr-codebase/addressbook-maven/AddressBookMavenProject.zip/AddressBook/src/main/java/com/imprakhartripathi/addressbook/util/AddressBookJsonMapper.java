package com.imprakhartripathi.addressbook.util;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;

import java.util.ArrayList;
import java.util.List;

public final class AddressBookJsonMapper {
    private AddressBookJsonMapper() {
    }

    public static AddressBookDto toDto(AddressBook addressBook) {
        AddressBookDto dto = new AddressBookDto();
        dto.name = addressBook.name();
        dto.contacts = new ArrayList<>();
        for (Contact contact : addressBook.contacts()) {
            ContactDto contactDto = new ContactDto();
            contactDto.firstName = contact.name().firstName();
            contactDto.lastName = contact.name().lastName();
            contactDto.address = contact.address().street();
            contactDto.city = contact.address().city();
            contactDto.state = contact.address().state();
            contactDto.zip = contact.address().zipCode().value();
            contactDto.phone = contact.phoneNumber().value();
            contactDto.email = contact.emailAddress().value();
            dto.contacts.add(contactDto);
        }
        return dto;
    }

    public static AddressBook fromDto(AddressBookDto dto) {
        AddressBook addressBook = new AddressBook(dto.name);
        if (dto.contacts == null) {
            return addressBook;
        }
        for (ContactDto contactDto : dto.contacts) {
            Name name = new Name(contactDto.firstName, contactDto.lastName);
            Address address = new Address(contactDto.address, contactDto.city, contactDto.state, new ZipCode(contactDto.zip));
            PhoneNumber phone = new PhoneNumber(contactDto.phone);
            EmailAddress email = new EmailAddress(contactDto.email);
            addressBook.add(new Contact(name, address, phone, email));
        }
        return addressBook;
    }

    public static class AddressBookDto {
        public String name;
        public List<ContactDto> contacts;
    }

    public static class ContactDto {
        public String firstName;
        public String lastName;
        public String address;
        public String city;
        public String state;
        public String zip;
        public String phone;
        public String email;
    }
}
