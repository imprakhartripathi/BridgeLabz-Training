package com.imprakhartripathi.addressbook.util;

import java.nio.file.Path;

public final class StoragePaths {
    private static final Path BASE_DIR = Path.of(System.getProperty("addressbook.data.dir", "data"));

    private StoragePaths() {
    }

    public static Path filePath(String addressBookName) {
        return BASE_DIR.resolve("txt").resolve(addressBookName + ".txt");
    }

    public static Path csvPath(String addressBookName) {
        return BASE_DIR.resolve("csv").resolve(addressBookName + ".csv");
    }

    public static Path jsonPath(String addressBookName) {
        return BASE_DIR.resolve("json").resolve(addressBookName + ".json");
    }

    public static Path dbPath() {
        return BASE_DIR.resolve("db").resolve("addressbook");
    }
}
