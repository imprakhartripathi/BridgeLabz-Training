package com.imprakhartripathi.addressbook.service;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.repository.AddressBookRepository;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public interface AddressBookService {
    void setRepository(AddressBookRepository repository);

    void createAddressBook(String name);

    List<String> listAddressBooks();

    void addContact(String bookName, Contact contact);

    void editContact(String bookName, String firstName, String lastName, Address address,
                     PhoneNumber phoneNumber, EmailAddress emailAddress);

    void deleteContact(String bookName, String firstName, String lastName);

    List<Contact> searchByCity(String city);

    List<Contact> searchByState(String state);

    Map<String, List<Contact>> groupByCity();

    Map<String, List<Contact>> groupByState();

    Map<String, Long> countByCity();

    Map<String, Long> countByState();

    List<Contact> sortContacts(String bookName, SortField sortField);

    CompletableFuture<Void> saveAddressBook(String bookName);

    CompletableFuture<AddressBook> loadAddressBook(String bookName);

    CompletableFuture<Void> deleteAddressBook(String bookName);
}
