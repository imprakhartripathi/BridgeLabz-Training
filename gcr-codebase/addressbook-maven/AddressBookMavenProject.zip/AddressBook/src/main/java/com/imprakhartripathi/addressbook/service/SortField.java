package com.imprakhartripathi.addressbook.service;

public enum SortField {
    NAME,
    CITY,
    STATE,
    ZIP
}
