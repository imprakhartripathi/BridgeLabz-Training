package com.imprakhartripathi.addressbook.presentation;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;
import com.imprakhartripathi.addressbook.exception.AddressBookException;
import com.imprakhartripathi.addressbook.repository.AddressBookRepository;
import com.imprakhartripathi.addressbook.repository.CSVRepository;
import com.imprakhartripathi.addressbook.repository.DatabaseRepository;
import com.imprakhartripathi.addressbook.repository.FileRepository;
import com.imprakhartripathi.addressbook.repository.JSONRepository;
import com.imprakhartripathi.addressbook.repository.JsonServerRepository;
import com.imprakhartripathi.addressbook.service.AddressBookService;
import com.imprakhartripathi.addressbook.service.AddressBookServiceImpl;
import com.imprakhartripathi.addressbook.service.SortField;
import com.imprakhartripathi.addressbook.util.AsyncExecutorProvider;
import com.imprakhartripathi.addressbook.util.SampleDataLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class AddressBookApplication {
    private static final Logger logger = LoggerFactory.getLogger(AddressBookApplication.class);

    private final AddressBookService service;
    private final Scanner scanner;
    private String currentBook;

    public AddressBookApplication(AddressBookService service) {
        this.service = service;
        this.scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        AddressBookRepository repository = new FileRepository(AsyncExecutorProvider.ioExecutor());
        AddressBookService service = new AddressBookServiceImpl(repository);
        new AddressBookApplication(service).run();
    }

    public void run() {
        System.out.println("Welcome to Address Book Program");
        boolean running = true;
        while (running) {
            printMenu();
            String choice = read("Choose an option");
            try {
                switch (choice) {
                    case "1" -> createAddressBook();
                    case "2" -> selectAddressBook();
                    case "3" -> addContact();
                    case "4" -> editContact();
                    case "5" -> deleteContact();
                    case "6" -> search();
                    case "7" -> groupView();
                    case "8" -> countView();
                    case "9" -> sortContacts();
                    case "10" -> persistMenu();
                    case "11" -> switchRepository();
                    case "12" -> loadSampleData();
                    case "0" -> running = false;
                    default -> System.out.println("Invalid option");
                }
            } catch (AddressBookException | IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                logger.warn("Operation failed", e);
            }
        }
        System.out.println("Goodbye");
    }

    private void printMenu() {
        System.out.println("\n--- Address Book Menu ---");
        System.out.println("1. Create Address Book");
        System.out.println("2. Select Address Book");
        System.out.println("3. Add Contact");
        System.out.println("4. Edit Contact");
        System.out.println("5. Delete Contact");
        System.out.println("6. Search by City/State");
        System.out.println("7. View Grouped by City/State");
        System.out.println("8. Count by City/State");
        System.out.println("9. Sort Contacts");
        System.out.println("10. Save/Load/Delete Address Book");
        System.out.println("11. Switch Repository (TXT/CSV/JSON/JSON Server/DB)");
        System.out.println("12. Load Sample Data");
        System.out.println("0. Exit");
        if (currentBook != null) {
            System.out.println("Current book: " + currentBook);
        }
    }

    private void createAddressBook() {
        String name = read("Address book name");
        service.createAddressBook(name);
        currentBook = name;
    }

    private void selectAddressBook() {
        List<String> books = service.listAddressBooks();
        if (books.isEmpty()) {
            System.out.println("No address books available");
            return;
        }
        System.out.println("Available: " + String.join(", ", books));
        currentBook = read("Enter address book name");
    }

    private void addContact() {
        String book = requireCurrentBook();
        Contact contact = readContact();
        service.addContact(book, contact);
        System.out.println("Contact added");
    }

    private void editContact() {
        String book = requireCurrentBook();
        String first = read("First name");
        String last = read("Last name");
        Address address = readAddress();
        PhoneNumber phone = new PhoneNumber(read("Phone number"));
        EmailAddress email = new EmailAddress(read("Email"));
        service.editContact(book, first, last, address, phone, email);
        System.out.println("Contact updated");
    }

    private void deleteContact() {
        String book = requireCurrentBook();
        String first = read("First name");
        String last = read("Last name");
        service.deleteContact(book, first, last);
        System.out.println("Contact deleted");
    }

    private void search() {
        String type = read("Search by 1) City or 2) State");
        String value = read("Enter search value");
        List<Contact> results = "1".equals(type) ? service.searchByCity(value) : service.searchByState(value);
        if (results.isEmpty()) {
            System.out.println("No contacts found");
            return;
        }
        results.forEach(System.out::println);
    }

    private void groupView() {
        String type = read("Group by 1) City or 2) State");
        Map<String, List<Contact>> grouped = "1".equals(type) ? service.groupByCity() : service.groupByState();
        grouped.forEach((key, contacts) -> {
            System.out.println(key + ":");
            contacts.forEach(contact -> System.out.println("  " + contact));
        });
    }

    private void countView() {
        String type = read("Count by 1) City or 2) State");
        Map<String, Long> counts = "1".equals(type) ? service.countByCity() : service.countByState();
        counts.forEach((key, count) -> System.out.println(key + ": " + count));
    }

    private void sortContacts() {
        String book = requireCurrentBook();
        String type = read("Sort by 1) Name 2) City 3) State 4) Zip");
        SortField sortField = switch (type) {
            case "1" -> SortField.NAME;
            case "2" -> SortField.CITY;
            case "3" -> SortField.STATE;
            case "4" -> SortField.ZIP;
            default -> SortField.NAME;
        };
        List<Contact> sorted = service.sortContacts(book, sortField);
        sorted.forEach(System.out::println);
    }

    private void persistMenu() {
        String book = requireCurrentBook();
        String type = read("1) Save 2) Load 3) Delete");
        switch (type) {
            case "1" -> service.saveAddressBook(book).join();
            case "2" -> service.loadAddressBook(book).join();
            case "3" -> service.deleteAddressBook(book).join();
            default -> System.out.println("Invalid option");
        }
        System.out.println("Done");
    }

    private void switchRepository() {
        String type = read("Repository 1) TXT 2) CSV 3) JSON 4) JSON Server 5) DB");
        AddressBookRepository repository = switch (type) {
            case "1" -> new FileRepository(AsyncExecutorProvider.ioExecutor());
            case "2" -> new CSVRepository(AsyncExecutorProvider.ioExecutor());
            case "3" -> new JSONRepository(AsyncExecutorProvider.ioExecutor());
            case "4" -> new JsonServerRepository(AsyncExecutorProvider.ioExecutor(), read("Base URL"));
            case "5" -> new DatabaseRepository(AsyncExecutorProvider.ioExecutor());
            default -> new FileRepository(AsyncExecutorProvider.ioExecutor());
        };
        service.setRepository(repository);
        System.out.println("Repository switched");
    }

    private void loadSampleData() {
        SampleDataLoader.load(service);
        currentBook = "personal";
        System.out.println("Sample data loaded. Current book: " + currentBook);
    }

    private Contact readContact() {
        Name name = new Name(read("First name"), read("Last name"));
        Address address = readAddress();
        PhoneNumber phone = new PhoneNumber(read("Phone number"));
        EmailAddress email = new EmailAddress(read("Email"));
        return new Contact(name, address, phone, email);
    }

    private Address readAddress() {
        String street = read("Address");
        String city = read("City");
        String state = read("State");
        String zip = read("Zip");
        return new Address(street, city, state, new ZipCode(zip));
    }

    private String requireCurrentBook() {
        if (currentBook == null || currentBook.isBlank()) {
            throw new IllegalArgumentException("Select an address book first");
        }
        return currentBook;
    }

    private String read(String prompt) {
        System.out.print(prompt + ": ");
        return scanner.nextLine().trim();
    }
}
