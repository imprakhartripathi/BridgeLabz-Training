package com.imprakhartripathi.addressbook.exception;

public class ValidationException extends AddressBookException {
    public ValidationException(String message) {
        super(message);
    }
}
