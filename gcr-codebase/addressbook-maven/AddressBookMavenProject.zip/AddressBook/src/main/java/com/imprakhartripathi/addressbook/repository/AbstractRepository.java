package com.imprakhartripathi.addressbook.repository;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public abstract class AbstractRepository implements AddressBookRepository {
    protected final ExecutorService executor;
    protected final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    protected AbstractRepository(ExecutorService executor) {
        this.executor = executor;
    }
}
