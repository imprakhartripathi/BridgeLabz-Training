package com.imprakhartripathi.addressbook.repository;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;
import com.imprakhartripathi.addressbook.exception.PersistenceException;
import com.imprakhartripathi.addressbook.util.StoragePaths;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class FileRepository extends AbstractRepository {
    public FileRepository(java.util.concurrent.ExecutorService executor) {
        super(executor);
    }

    @Override
    public CompletableFuture<Void> save(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<AddressBook> load(String addressBookName) {
        return CompletableFuture.supplyAsync(() -> read(addressBookName), executor);
    }

    @Override
    public CompletableFuture<Void> update(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<Void> delete(String addressBookName) {
        return CompletableFuture.runAsync(() -> deleteInternal(addressBookName), executor);
    }

    private void write(AddressBook addressBook) {
        lock.writeLock().lock();
        try {
            Path path = StoragePaths.filePath(addressBook.name());
            Files.createDirectories(path.getParent());
            List<String> lines = addressBook.contacts().stream()
                    .map(this::toLine)
                    .toList();
            Files.write(path, lines);
        } catch (IOException e) {
            throw new PersistenceException("Failed to write address book", e);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private AddressBook read(String addressBookName) {
        lock.readLock().lock();
        try {
            Path path = StoragePaths.filePath(addressBookName);
            AddressBook addressBook = new AddressBook(addressBookName);
            if (!Files.exists(path)) {
                return addressBook;
            }
            List<String> lines = Files.readAllLines(path);
            for (String line : lines) {
                if (line.isBlank()) {
                    continue;
                }
                Contact contact = fromLine(line);
                addressBook.add(contact);
            }
            return addressBook;
        } catch (IOException e) {
            throw new PersistenceException("Failed to read address book", e);
        } finally {
            lock.readLock().unlock();
        }
    }

    private void deleteInternal(String addressBookName) {
        lock.writeLock().lock();
        try {
            Path path = StoragePaths.filePath(addressBookName);
            if (Files.exists(path)) {
                Files.delete(path);
            }
        } catch (IOException e) {
            throw new PersistenceException("Failed to delete address book", e);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private String toLine(Contact contact) {
        return String.join("|",
                contact.name().firstName(),
                contact.name().lastName(),
                contact.address().street(),
                contact.address().city(),
                contact.address().state(),
                contact.address().zipCode().value(),
                contact.phoneNumber().value(),
                contact.emailAddress().value()
        );
    }

    private Contact fromLine(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 8) {
            throw new PersistenceException("Invalid contact line", null);
        }
        Name name = new Name(parts[0], parts[1]);
        Address address = new Address(parts[2], parts[3], parts[4], new ZipCode(parts[5]));
        PhoneNumber phoneNumber = new PhoneNumber(parts[6]);
        EmailAddress emailAddress = new EmailAddress(parts[7]);
        return new Contact(name, address, phoneNumber, emailAddress);
    }
}
