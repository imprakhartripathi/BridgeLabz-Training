package com.imprakhartripathi.addressbook.repository;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;
import com.imprakhartripathi.addressbook.exception.PersistenceException;
import com.imprakhartripathi.addressbook.util.StoragePaths;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class CSVRepository extends AbstractRepository {
    public CSVRepository(java.util.concurrent.ExecutorService executor) {
        super(executor);
    }

    @Override
    public CompletableFuture<Void> save(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<AddressBook> load(String addressBookName) {
        return CompletableFuture.supplyAsync(() -> read(addressBookName), executor);
    }

    @Override
    public CompletableFuture<Void> update(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<Void> delete(String addressBookName) {
        return CompletableFuture.runAsync(() -> deleteInternal(addressBookName), executor);
    }

    private void write(AddressBook addressBook) {
        lock.writeLock().lock();
        try {
            Path path = StoragePaths.csvPath(addressBook.name());
            Files.createDirectories(path.getParent());
            try (CSVWriter writer = new CSVWriter(Files.newBufferedWriter(path))) {
                for (Contact contact : addressBook.contacts()) {
                    writer.writeNext(toRow(contact));
                }
            }
        } catch (IOException e) {
            throw new PersistenceException("Failed to write CSV", e);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private AddressBook read(String addressBookName) {
        lock.readLock().lock();
        try {
            Path path = StoragePaths.csvPath(addressBookName);
            AddressBook addressBook = new AddressBook(addressBookName);
            if (!Files.exists(path)) {
                return addressBook;
            }
            try (CSVReader reader = new CSVReader(Files.newBufferedReader(path))) {
                String[] row;
                while ((row = reader.readNext()) != null) {
                    if (row.length < 8) {
                        continue;
                    }
                    addressBook.add(fromRow(row));
                }
            }
            return addressBook;
        } catch (Exception e) {
            throw new PersistenceException("Failed to read CSV", e);
        } finally {
            lock.readLock().unlock();
        }
    }

    private void deleteInternal(String addressBookName) {
        lock.writeLock().lock();
        try {
            Path path = StoragePaths.csvPath(addressBookName);
            if (Files.exists(path)) {
                Files.delete(path);
            }
        } catch (IOException e) {
            throw new PersistenceException("Failed to delete CSV", e);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private String[] toRow(Contact contact) {
        List<String> row = new ArrayList<>();
        row.add(contact.name().firstName());
        row.add(contact.name().lastName());
        row.add(contact.address().street());
        row.add(contact.address().city());
        row.add(contact.address().state());
        row.add(contact.address().zipCode().value());
        row.add(contact.phoneNumber().value());
        row.add(contact.emailAddress().value());
        return row.toArray(String[]::new);
    }

    private Contact fromRow(String[] row) {
        Name name = new Name(row[0], row[1]);
        Address address = new Address(row[2], row[3], row[4], new ZipCode(row[5]));
        PhoneNumber phoneNumber = new PhoneNumber(row[6]);
        EmailAddress emailAddress = new EmailAddress(row[7]);
        return new Contact(name, address, phoneNumber, emailAddress);
    }
}
