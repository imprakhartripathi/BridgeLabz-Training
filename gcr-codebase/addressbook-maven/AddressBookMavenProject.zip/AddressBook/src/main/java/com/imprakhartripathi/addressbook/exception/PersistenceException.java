package com.imprakhartripathi.addressbook.exception;

public class PersistenceException extends AddressBookException {
    public PersistenceException(String message, Throwable cause) {
        super(message, cause);
    }
}
