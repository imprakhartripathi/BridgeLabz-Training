package com.imprakhartripathi.addressbook.service;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.domain.AddressBookSystem;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.exception.AddressBookNotFoundException;
import com.imprakhartripathi.addressbook.exception.ContactNotFoundException;
import com.imprakhartripathi.addressbook.exception.DuplicateAddressBookException;
import com.imprakhartripathi.addressbook.exception.DuplicateContactException;
import com.imprakhartripathi.addressbook.repository.AddressBookRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Collectors;

public class AddressBookServiceImpl implements AddressBookService {
    private static final Logger logger = LoggerFactory.getLogger(AddressBookServiceImpl.class);

    private final AddressBookSystem system;
    private AddressBookRepository repository;

    public AddressBookServiceImpl(AddressBookRepository repository) {
        this.repository = Objects.requireNonNull(repository, "Repository is required");
        this.system = new AddressBookSystem();
    }

    @Override
    public void setRepository(AddressBookRepository repository) {
        this.repository = Objects.requireNonNull(repository, "Repository is required");
    }

    @Override
    public void createAddressBook(String name) {
        if (system.find(name).isPresent()) {
            throw new DuplicateAddressBookException("Address book already exists: " + name);
        }
        system.add(new AddressBook(name));
        logger.info("Created address book: {}", name);
    }

    @Override
    public List<String> listAddressBooks() {
        return system.list().stream().map(AddressBook::name).toList();
    }

    @Override
    public void addContact(String bookName, Contact contact) {
        AddressBook addressBook = getAddressBook(bookName);
        if (addressBook.findByName(contact.name()).isPresent()) {
            throw new DuplicateContactException("Duplicate contact: " + contact.name().fullName());
        }
        addressBook.add(contact);
        logger.info("Added contact {} to {}", contact.name().fullName(), bookName);
    }

    @Override
    public void editContact(String bookName, String firstName, String lastName, Address address,
                            PhoneNumber phoneNumber, EmailAddress emailAddress) {
        AddressBook addressBook = getAddressBook(bookName);
        Name name = new Name(firstName, lastName);
        Contact contact = addressBook.findByName(name)
                .orElseThrow(() -> new ContactNotFoundException("Contact not found: " + name.fullName()));
        contact.updateAddress(address);
        contact.updatePhone(phoneNumber);
        contact.updateEmail(emailAddress);
        logger.info("Updated contact {} in {}", name.fullName(), bookName);
    }

    @Override
    public void deleteContact(String bookName, String firstName, String lastName) {
        AddressBook addressBook = getAddressBook(bookName);
        Name name = new Name(firstName, lastName);
        if (addressBook.findByName(name).isEmpty()) {
            throw new ContactNotFoundException("Contact not found: " + name.fullName());
        }
        addressBook.remove(name);
        logger.info("Deleted contact {} from {}", name.fullName(), bookName);
    }

    @Override
    public List<Contact> searchByCity(String city) {
        return findAcrossBooks(contact -> contact.address().city().equalsIgnoreCase(city));
    }

    @Override
    public List<Contact> searchByState(String state) {
        return findAcrossBooks(contact -> contact.address().state().equalsIgnoreCase(state));
    }

    @Override
    public Map<String, List<Contact>> groupByCity() {
        return groupBy(contact -> contact.address().city());
    }

    @Override
    public Map<String, List<Contact>> groupByState() {
        return groupBy(contact -> contact.address().state());
    }

    @Override
    public Map<String, Long> countByCity() {
        return countBy(contact -> contact.address().city());
    }

    @Override
    public Map<String, Long> countByState() {
        return countBy(contact -> contact.address().state());
    }

    @Override
    public List<Contact> sortContacts(String bookName, SortField sortField) {
        AddressBook addressBook = getAddressBook(bookName);
        Comparator<Contact> comparator = switch (sortField) {
            case NAME -> Comparator.comparing(c -> c.name().fullName().toLowerCase());
            case CITY -> Comparator.comparing(c -> c.address().city().toLowerCase());
            case STATE -> Comparator.comparing(c -> c.address().state().toLowerCase());
            case ZIP -> Comparator.comparing(c -> c.address().zipCode().value());
        };
        return addressBook.contacts().stream().sorted(comparator).toList();
    }

    @Override
    public CompletableFuture<Void> saveAddressBook(String bookName) {
        AddressBook addressBook = getAddressBook(bookName);
        return repository.save(addressBook);
    }

    @Override
    public CompletableFuture<AddressBook> loadAddressBook(String bookName) {
        return repository.load(bookName).thenApply(addressBook -> {
            system.add(addressBook);
            logger.info("Loaded address book {}", bookName);
            return addressBook;
        });
    }

    @Override
    public CompletableFuture<Void> deleteAddressBook(String bookName) {
        system.remove(bookName);
        return repository.delete(bookName);
    }

    private AddressBook getAddressBook(String bookName) {
        return system.find(bookName)
                .orElseThrow(() -> new AddressBookNotFoundException("Address book not found: " + bookName));
    }

    private List<Contact> findAcrossBooks(java.util.function.Predicate<Contact> predicate) {
        return system.list().stream()
                .flatMap(book -> book.contacts().stream())
                .filter(predicate)
                .toList();
    }

    private Map<String, List<Contact>> groupBy(Function<Contact, String> classifier) {
        return system.list().stream()
                .flatMap(book -> book.contacts().stream())
                .collect(Collectors.groupingBy(classifier));
    }

    private Map<String, Long> countBy(Function<Contact, String> classifier) {
        return system.list().stream()
                .flatMap(book -> book.contacts().stream())
                .collect(Collectors.groupingBy(classifier, Collectors.counting()));
    }
}
