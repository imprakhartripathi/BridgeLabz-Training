package com.imprakhartripathi.addressbook.exception;

public class DuplicateAddressBookException extends AddressBookException {
    public DuplicateAddressBookException(String message) {
        super(message);
    }
}
