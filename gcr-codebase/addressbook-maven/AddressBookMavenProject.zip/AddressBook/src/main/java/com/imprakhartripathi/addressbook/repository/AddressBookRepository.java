package com.imprakhartripathi.addressbook.repository;

import com.imprakhartripathi.addressbook.domain.AddressBook;

import java.util.concurrent.CompletableFuture;

public interface AddressBookRepository {
    CompletableFuture<Void> save(AddressBook addressBook);

    CompletableFuture<AddressBook> load(String addressBookName);

    CompletableFuture<Void> update(AddressBook addressBook);

    CompletableFuture<Void> delete(String addressBookName);
}
