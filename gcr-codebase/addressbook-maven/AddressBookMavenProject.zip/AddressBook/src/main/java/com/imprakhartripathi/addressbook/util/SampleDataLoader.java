package com.imprakhartripathi.addressbook.util;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;
import com.imprakhartripathi.addressbook.service.AddressBookService;

public final class SampleDataLoader {
    private SampleDataLoader() {
    }

    public static void load(AddressBookService service) {
        service.createAddressBook("personal");
        service.addContact("personal", new Contact(
                new Name("Aarav", "Sharma"),
                new Address("12 Lake View", "Pune", "Maharashtra", new ZipCode("411001")),
                new PhoneNumber("9876543210"),
                new EmailAddress("aarav.sharma@example.com")
        ));
        service.addContact("personal", new Contact(
                new Name("Diya", "Nair"),
                new Address("18 Park Street", "Kochi", "Kerala", new ZipCode("682001")),
                new PhoneNumber("9123456780"),
                new EmailAddress("diya.nair@example.com")
        ));

        service.createAddressBook("work");
        service.addContact("work", new Contact(
                new Name("Vikram", "Rao"),
                new Address("91 MG Road", "Bengaluru", "Karnataka", new ZipCode("560001")),
                new PhoneNumber("9988776655"),
                new EmailAddress("vikram.rao@example.com")
        ));
        service.addContact("work", new Contact(
                new Name("Anaya", "Kapoor"),
                new Address("7 Nehru Place", "Delhi", "Delhi", new ZipCode("110019")),
                new PhoneNumber("9012345678"),
                new EmailAddress("anaya.kapoor@example.com")
        ));
    }
}
