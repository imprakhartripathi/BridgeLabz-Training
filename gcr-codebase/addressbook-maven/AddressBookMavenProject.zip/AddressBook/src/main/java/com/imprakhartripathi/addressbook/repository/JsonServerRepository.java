package com.imprakhartripathi.addressbook.repository;

import com.google.gson.Gson;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.exception.PersistenceException;
import com.imprakhartripathi.addressbook.util.AddressBookJsonMapper;
import com.imprakhartripathi.addressbook.util.JsonUtil;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.CompletableFuture;

public class JsonServerRepository extends AbstractRepository {
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final Gson gson = JsonUtil.gson();
    private final String baseUrl;

    public JsonServerRepository(java.util.concurrent.ExecutorService executor, String baseUrl) {
        super(executor);
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
    }

    @Override
    public CompletableFuture<Void> save(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> put(addressBook), executor);
    }

    @Override
    public CompletableFuture<AddressBook> load(String addressBookName) {
        return CompletableFuture.supplyAsync(() -> get(addressBookName), executor);
    }

    @Override
    public CompletableFuture<Void> update(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> put(addressBook), executor);
    }

    @Override
    public CompletableFuture<Void> delete(String addressBookName) {
        return CompletableFuture.runAsync(() -> deleteInternal(addressBookName), executor);
    }

    private void put(AddressBook addressBook) {
        try {
            String body = gson.toJson(AddressBookJsonMapper.toDto(addressBook));
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + "/" + addressBook.name()))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() >= 400) {
                throw new PersistenceException("Failed to save to JSON server: " + response.statusCode(), null);
            }
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PersistenceException("Failed to save to JSON server", e);
        }
    }

    private AddressBook get(String addressBookName) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + "/" + addressBookName))
                    .GET()
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 404) {
                return new AddressBook(addressBookName);
            }
            if (response.statusCode() >= 400) {
                throw new PersistenceException("Failed to load from JSON server: " + response.statusCode(), null);
            }
            AddressBookJsonMapper.AddressBookDto dto = gson.fromJson(response.body(), AddressBookJsonMapper.AddressBookDto.class);
            return dto == null ? new AddressBook(addressBookName) : AddressBookJsonMapper.fromDto(dto);
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PersistenceException("Failed to load from JSON server", e);
        }
    }

    private void deleteInternal(String addressBookName) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + "/" + addressBookName))
                    .DELETE()
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() >= 400) {
                throw new PersistenceException("Failed to delete from JSON server: " + response.statusCode(), null);
            }
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PersistenceException("Failed to delete from JSON server", e);
        }
    }
}
