package com.imprakhartripathi.addressbook.domain;

import java.util.Objects;

public class Address {
    private String street;
    private String city;
    private String state;
    private ZipCode zipCode;

    public Address(String street, String city, String state, ZipCode zipCode) {
        this.street = requireNonBlank(street, "Address");
        this.city = requireNonBlank(city, "City");
        this.state = requireNonBlank(state, "State");
        this.zipCode = Objects.requireNonNull(zipCode, "Zip code is required");
    }

    public String street() {
        return street;
    }

    public String city() {
        return city;
    }

    public String state() {
        return state;
    }

    public ZipCode zipCode() {
        return zipCode;
    }

    public void update(String street, String city, String state, ZipCode zipCode) {
        this.street = requireNonBlank(street, "Address");
        this.city = requireNonBlank(city, "City");
        this.state = requireNonBlank(state, "State");
        this.zipCode = Objects.requireNonNull(zipCode, "Zip code is required");
    }

    private static String requireNonBlank(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(field + " cannot be blank");
        }
        return value.trim();
    }

    @Override
    public String toString() {
        return street + ", " + city + ", " + state + " " + zipCode;
    }
}
