package com.imprakhartripathi.addressbook.exception;

public class AddressBookNotFoundException extends AddressBookException {
    public AddressBookNotFoundException(String message) {
        super(message);
    }
}
