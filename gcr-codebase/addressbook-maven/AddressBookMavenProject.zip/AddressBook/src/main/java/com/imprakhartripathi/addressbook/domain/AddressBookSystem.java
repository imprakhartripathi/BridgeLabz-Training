package com.imprakhartripathi.addressbook.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class AddressBookSystem {
    private final Map<String, AddressBook> addressBooks = new LinkedHashMap<>();

    public void add(AddressBook addressBook) {
        addressBooks.put(addressBook.name(), addressBook);
    }

    public Optional<AddressBook> find(String name) {
        return Optional.ofNullable(addressBooks.get(name));
    }

    public void remove(String name) {
        addressBooks.remove(name);
    }

    public List<AddressBook> list() {
        return Collections.unmodifiableList(new ArrayList<>(addressBooks.values()));
    }

    public Map<String, AddressBook> view() {
        return Collections.unmodifiableMap(addressBooks);
    }
}
