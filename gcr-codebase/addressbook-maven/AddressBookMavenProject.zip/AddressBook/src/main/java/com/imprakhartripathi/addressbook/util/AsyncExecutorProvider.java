package com.imprakhartripathi.addressbook.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class AsyncExecutorProvider {
    private static final ExecutorService IO_EXECUTOR = Executors.newFixedThreadPool(
            Math.max(4, Runtime.getRuntime().availableProcessors())
    );

    private AsyncExecutorProvider() {
    }

    public static ExecutorService ioExecutor() {
        return IO_EXECUTOR;
    }
}
