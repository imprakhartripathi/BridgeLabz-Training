package com.imprakhartripathi.addressbook.exception;

public class DuplicateContactException extends AddressBookException {
    public DuplicateContactException(String message) {
        super(message);
    }
}
