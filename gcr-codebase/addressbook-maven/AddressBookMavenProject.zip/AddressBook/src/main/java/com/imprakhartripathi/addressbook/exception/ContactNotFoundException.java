package com.imprakhartripathi.addressbook.exception;

public class ContactNotFoundException extends AddressBookException {
    public ContactNotFoundException(String message) {
        super(message);
    }
}
