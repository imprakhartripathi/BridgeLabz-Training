package com.imprakhartripathi.addressbook.domain;

import java.util.Objects;

public final class ZipCode {
    private final String value;

    public ZipCode(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Zip code cannot be blank");
        }
        this.value = value.trim();
    }

    public String value() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ZipCode zipCode = (ZipCode) o;
        return value.equals(zipCode.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }

    @Override
    public String toString() {
        return value;
    }
}
