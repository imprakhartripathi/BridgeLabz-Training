package com.imprakhartripathi.addressbook.repository;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;
import com.imprakhartripathi.addressbook.exception.PersistenceException;
import com.imprakhartripathi.addressbook.util.StoragePaths;

import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.CompletableFuture;

public class DatabaseRepository extends AbstractRepository {
    private final String jdbcUrl;

    public DatabaseRepository(java.util.concurrent.ExecutorService executor) {
        super(executor);
        this.jdbcUrl = "jdbc:h2:" + StoragePaths.dbPath().toAbsolutePath();
        init();
    }

    @Override
    public CompletableFuture<Void> save(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<AddressBook> load(String addressBookName) {
        return CompletableFuture.supplyAsync(() -> read(addressBookName), executor);
    }

    @Override
    public CompletableFuture<Void> update(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<Void> delete(String addressBookName) {
        return CompletableFuture.runAsync(() -> deleteInternal(addressBookName), executor);
    }

    private void init() {
        try {
            Files.createDirectories(StoragePaths.dbPath().getParent());
            try (Connection connection = DriverManager.getConnection(jdbcUrl);
                 PreparedStatement statement = connection.prepareStatement(
                         "CREATE TABLE IF NOT EXISTS ADDRESS_BOOK_CONTACTS (" +
                                 "book_name VARCHAR(128)," +
                                 "first_name VARCHAR(64)," +
                                 "last_name VARCHAR(64)," +
                                 "address VARCHAR(256)," +
                                 "city VARCHAR(64)," +
                                 "state VARCHAR(64)," +
                                 "zip VARCHAR(16)," +
                                 "phone VARCHAR(32)," +
                                 "email VARCHAR(128)," +
                                 "PRIMARY KEY (book_name, first_name, last_name))")) {
                statement.execute();
            }
        } catch (Exception e) {
            throw new PersistenceException("Failed to initialize database", e);
        }
    }

    private void write(AddressBook addressBook) {
        lock.writeLock().lock();
        try (Connection connection = DriverManager.getConnection(jdbcUrl)) {
            connection.setAutoCommit(false);
            try (PreparedStatement deleteStmt = connection.prepareStatement(
                    "DELETE FROM ADDRESS_BOOK_CONTACTS WHERE book_name = ?")) {
                deleteStmt.setString(1, addressBook.name());
                deleteStmt.executeUpdate();
            }
            try (PreparedStatement insertStmt = connection.prepareStatement(
                    "INSERT INTO ADDRESS_BOOK_CONTACTS (book_name, first_name, last_name, address, city, state, zip, phone, email) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                for (Contact contact : addressBook.contacts()) {
                    insertStmt.setString(1, addressBook.name());
                    insertStmt.setString(2, contact.name().firstName());
                    insertStmt.setString(3, contact.name().lastName());
                    insertStmt.setString(4, contact.address().street());
                    insertStmt.setString(5, contact.address().city());
                    insertStmt.setString(6, contact.address().state());
                    insertStmt.setString(7, contact.address().zipCode().value());
                    insertStmt.setString(8, contact.phoneNumber().value());
                    insertStmt.setString(9, contact.emailAddress().value());
                    insertStmt.addBatch();
                }
                insertStmt.executeBatch();
            }
            connection.commit();
        } catch (SQLException e) {
            throw new PersistenceException("Failed to write to database", e);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private AddressBook read(String addressBookName) {
        lock.readLock().lock();
        AddressBook addressBook = new AddressBook(addressBookName);
        try (Connection connection = DriverManager.getConnection(jdbcUrl);
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT * FROM ADDRESS_BOOK_CONTACTS WHERE book_name = ?")) {
            statement.setString(1, addressBookName);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Name name = new Name(rs.getString("first_name"), rs.getString("last_name"));
                    Address address = new Address(
                            rs.getString("address"),
                            rs.getString("city"),
                            rs.getString("state"),
                            new ZipCode(rs.getString("zip"))
                    );
                    PhoneNumber phone = new PhoneNumber(rs.getString("phone"));
                    EmailAddress email = new EmailAddress(rs.getString("email"));
                    addressBook.add(new Contact(name, address, phone, email));
                }
            }
        } catch (SQLException e) {
            throw new PersistenceException("Failed to read from database", e);
        } finally {
            lock.readLock().unlock();
        }
        return addressBook;
    }

    private void deleteInternal(String addressBookName) {
        lock.writeLock().lock();
        try (Connection connection = DriverManager.getConnection(jdbcUrl);
             PreparedStatement statement = connection.prepareStatement(
                     "DELETE FROM ADDRESS_BOOK_CONTACTS WHERE book_name = ?")) {
            statement.setString(1, addressBookName);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenceException("Failed to delete from database", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
}
