package com.imprakhartripathi.addressbook.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class AddressBook {
    private final String name;
    private final Map<Name, Contact> contacts = new LinkedHashMap<>();

    public AddressBook(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Address book name cannot be blank");
        }
        this.name = name.trim();
    }

    public String name() {
        return name;
    }

    public List<Contact> contacts() {
        return Collections.unmodifiableList(new ArrayList<>(contacts.values()));
    }

    public Optional<Contact> findByName(Name name) {
        return Optional.ofNullable(contacts.get(name));
    }

    public void add(Contact contact) {
        contacts.put(contact.name(), contact);
    }

    public void remove(Name name) {
        contacts.remove(name);
    }

    public void replace(Contact contact) {
        contacts.put(contact.name(), contact);
    }

    public Map<Name, Contact> contactsView() {
        return Collections.unmodifiableMap(contacts);
    }
}
