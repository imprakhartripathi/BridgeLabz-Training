package com.imprakhartripathi.addressbook.repository;

import com.google.gson.Gson;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.exception.PersistenceException;
import com.imprakhartripathi.addressbook.util.AddressBookJsonMapper;
import com.imprakhartripathi.addressbook.util.JsonUtil;
import com.imprakhartripathi.addressbook.util.StoragePaths;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public class JSONRepository extends AbstractRepository {
    private final Gson gson = JsonUtil.gson();

    public JSONRepository(java.util.concurrent.ExecutorService executor) {
        super(executor);
    }

    @Override
    public CompletableFuture<Void> save(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<AddressBook> load(String addressBookName) {
        return CompletableFuture.supplyAsync(() -> read(addressBookName), executor);
    }

    @Override
    public CompletableFuture<Void> update(AddressBook addressBook) {
        return CompletableFuture.runAsync(() -> write(addressBook), executor);
    }

    @Override
    public CompletableFuture<Void> delete(String addressBookName) {
        return CompletableFuture.runAsync(() -> deleteInternal(addressBookName), executor);
    }

    private void write(AddressBook addressBook) {
        lock.writeLock().lock();
        try {
            Path path = StoragePaths.jsonPath(addressBook.name());
            Files.createDirectories(path.getParent());
            Files.writeString(path, gson.toJson(AddressBookJsonMapper.toDto(addressBook)));
        } catch (IOException e) {
            throw new PersistenceException("Failed to write JSON", e);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private AddressBook read(String addressBookName) {
        lock.readLock().lock();
        try {
            Path path = StoragePaths.jsonPath(addressBookName);
            if (!Files.exists(path)) {
                return new AddressBook(addressBookName);
            }
            String json = Files.readString(path);
            AddressBookJsonMapper.AddressBookDto dto = gson.fromJson(json, AddressBookJsonMapper.AddressBookDto.class);
            return dto == null ? new AddressBook(addressBookName) : AddressBookJsonMapper.fromDto(dto);
        } catch (IOException e) {
            throw new PersistenceException("Failed to read JSON", e);
        } finally {
            lock.readLock().unlock();
        }
    }

    private void deleteInternal(String addressBookName) {
        lock.writeLock().lock();
        try {
            Path path = StoragePaths.jsonPath(addressBookName);
            if (Files.exists(path)) {
                Files.delete(path);
            }
        } catch (IOException e) {
            throw new PersistenceException("Failed to delete JSON", e);
        } finally {
            lock.writeLock().unlock();
        }
    }
}
