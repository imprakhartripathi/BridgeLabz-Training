package com.imprakhartripathi.addressbook.service;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;
import com.imprakhartripathi.addressbook.exception.DuplicateContactException;
import com.imprakhartripathi.addressbook.repository.AddressBookRepository;
import com.imprakhartripathi.addressbook.repository.FileRepository;
import com.imprakhartripathi.addressbook.util.AsyncExecutorProvider;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class AddressBookServiceImplTest {

    private AddressBookService createService() {
        AddressBookRepository repository = new FileRepository(AsyncExecutorProvider.ioExecutor());
        return new AddressBookServiceImpl(repository);
    }

    @Test
    void preventsDuplicateContactByName() {
        AddressBookService service = createService();
        service.createAddressBook("test");
        Contact contact = sample("Aarav", "Sharma", "Pune", "Maharashtra", "411001");
        service.addContact("test", contact);
        assertThrows(DuplicateContactException.class, () -> service.addContact("test", contact));
    }

    @Test
    void sortsContactsByCity() {
        AddressBookService service = createService();
        service.createAddressBook("test");
        service.addContact("test", sample("A", "One", "Mumbai", "Maharashtra", "400001"));
        service.addContact("test", sample("B", "Two", "Ahmedabad", "Gujarat", "380001"));

        List<Contact> sorted = service.sortContacts("test", SortField.CITY);
        assertEquals("Ahmedabad", sorted.getFirst().address().city());
        assertEquals("Mumbai", sorted.get(1).address().city());
    }

    @Test
    void countsByStateAcrossBooks() {
        AddressBookService service = createService();
        service.createAddressBook("book1");
        service.createAddressBook("book2");
        service.addContact("book1", sample("A", "One", "Pune", "Maharashtra", "411001"));
        service.addContact("book2", sample("B", "Two", "Mumbai", "Maharashtra", "400001"));
        service.addContact("book2", sample("C", "Three", "Surat", "Gujarat", "395001"));

        assertEquals(2L, service.countByState().get("Maharashtra"));
        assertEquals(1L, service.countByState().get("Gujarat"));
    }

    private Contact sample(String first, String last, String city, String state, String zip) {
        return new Contact(
                new Name(first, last),
                new Address("123 Main", city, state, new ZipCode(zip)),
                new PhoneNumber("9999999999"),
                new EmailAddress(first.toLowerCase() + "." + last.toLowerCase() + "@example.com")
        );
    }
}
