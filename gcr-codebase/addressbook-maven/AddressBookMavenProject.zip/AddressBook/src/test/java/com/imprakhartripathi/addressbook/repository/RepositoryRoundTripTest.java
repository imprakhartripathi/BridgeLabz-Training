package com.imprakhartripathi.addressbook.repository;

import com.imprakhartripathi.addressbook.domain.Address;
import com.imprakhartripathi.addressbook.domain.AddressBook;
import com.imprakhartripathi.addressbook.domain.Contact;
import com.imprakhartripathi.addressbook.domain.EmailAddress;
import com.imprakhartripathi.addressbook.domain.Name;
import com.imprakhartripathi.addressbook.domain.PhoneNumber;
import com.imprakhartripathi.addressbook.domain.ZipCode;
import com.imprakhartripathi.addressbook.util.AsyncExecutorProvider;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RepositoryRoundTripTest {
    private Path tempDir;

    @BeforeEach
    void setUp() throws Exception {
        tempDir = Files.createTempDirectory("addressbook-test");
        System.setProperty("addressbook.data.dir", tempDir.toString());
    }

    @AfterEach
    void tearDown() throws Exception {
        System.clearProperty("addressbook.data.dir");
        if (tempDir != null) {
            try (var paths = Files.walk(tempDir)) {
                paths.sorted((a, b) -> b.compareTo(a)).forEach(path -> {
                    try {
                        Files.deleteIfExists(path);
                    } catch (Exception ignored) {
                    }
                });
            }
        }
    }

    @Test
    void txtRepositoryRoundTrip() {
        AddressBookRepository repo = new FileRepository(AsyncExecutorProvider.ioExecutor());
        roundTrip(repo);
    }

    @Test
    void csvRepositoryRoundTrip() {
        AddressBookRepository repo = new CSVRepository(AsyncExecutorProvider.ioExecutor());
        roundTrip(repo);
    }

    @Test
    void jsonRepositoryRoundTrip() {
        AddressBookRepository repo = new JSONRepository(AsyncExecutorProvider.ioExecutor());
        roundTrip(repo);
    }

    private void roundTrip(AddressBookRepository repo) {
        AddressBook addressBook = new AddressBook("test");
        addressBook.add(new Contact(
                new Name("Aarav", "Sharma"),
                new Address("12 Lake View", "Pune", "Maharashtra", new ZipCode("411001")),
                new PhoneNumber("9876543210"),
                new EmailAddress("aarav.sharma@example.com")
        ));

        repo.save(addressBook).join();
        AddressBook loaded = repo.load("test").join();

        assertEquals(1, loaded.contacts().size());
        assertEquals("Aarav", loaded.contacts().getFirst().name().firstName());
        assertEquals("Pune", loaded.contacts().getFirst().address().city());
    }
}
