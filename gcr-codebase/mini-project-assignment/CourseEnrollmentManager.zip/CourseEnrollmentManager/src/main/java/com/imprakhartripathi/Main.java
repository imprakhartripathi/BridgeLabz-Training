package com.imprakhartripathi;

import com.imprakhartripathi.enrollment.EnrollmentImpl;
import com.imprakhartripathi.service.EnrollmentService;
import com.imprakhartripathi.service.EnrollmentServiceImpl;
import com.imprakhartripathi.ui.ConsoleApp;

public class Main {
    public static void main(String[] args) {
        EnrollmentService service = new EnrollmentServiceImpl(new EnrollmentImpl());
        ConsoleApp app = new ConsoleApp(service);
        app.run();
    }
}
