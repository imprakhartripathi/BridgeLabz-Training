package com.imprakhartripathi.enrollment;

import java.util.List;

public interface Enrollment {
    void add(com.imprakhartripathi.model.Enrollment enrollment);

    List<com.imprakhartripathi.model.Enrollment> findAll();
}
