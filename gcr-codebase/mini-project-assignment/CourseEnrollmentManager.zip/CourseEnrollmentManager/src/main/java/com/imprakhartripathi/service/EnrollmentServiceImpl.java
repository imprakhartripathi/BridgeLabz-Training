package com.imprakhartripathi.service;

import com.imprakhartripathi.enrollment.Enrollment;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EnrollmentServiceImpl implements EnrollmentService {
    private final Enrollment repository;

    public EnrollmentServiceImpl(Enrollment repository) {
        this.repository = repository;
    }

    @Override
    public void addEnrollment(com.imprakhartripathi.model.Enrollment enrollment) {
        repository.add(enrollment);
    }

    @Override
    public List<com.imprakhartripathi.model.Enrollment> getAllEnrollments() {
        return repository.findAll();
    }

    @Override
    public List<com.imprakhartripathi.model.Enrollment> filterByCourse(String courseName) {
        return repository.findAll().stream()
                .filter(e -> e.getCourseName().equalsIgnoreCase(courseName))
                .collect(Collectors.toList());
    }

    @Override
    public List<com.imprakhartripathi.model.Enrollment> filterByCategory(String category) {
        return repository.findAll().stream()
                .filter(e -> e.getCourseCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }

    @Override
    public Map<String, List<com.imprakhartripathi.model.Enrollment>> groupByCourse() {
        return repository.findAll().stream()
                .collect(Collectors.groupingBy(com.imprakhartripathi.model.Enrollment::getCourseName));
    }

    @Override
    public Map<String, Long> countByCategory() {
        return repository.findAll().stream()
                .collect(Collectors.groupingBy(com.imprakhartripathi.model.Enrollment::getCourseCategory, Collectors.counting()));
    }

    @Override
    public List<com.imprakhartripathi.model.Enrollment> sortByEnrollmentDate() {
        return repository.findAll().stream()
                .sorted(Comparator.comparing(com.imprakhartripathi.model.Enrollment::getEnrollmentDate))
                .collect(Collectors.toList());
    }
}
