package com.imprakhartripathi.model;

import java.time.LocalDate;

public class Enrollment {
    private final String studentName;
    private final String courseName;
    private final String courseCategory;
    private final LocalDate enrollmentDate;

    public Enrollment(String studentName, String courseName, String courseCategory, LocalDate enrollmentDate) {
        this.studentName = studentName;
        this.courseName = courseName;
        this.courseCategory = courseCategory;
        this.enrollmentDate = enrollmentDate;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseCategory() {
        return courseCategory;
    }

    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }

    @Override
    public String toString() {
        return "Enrollment{" +
                "studentName='" + studentName + '\'' +
                ", courseName='" + courseName + '\'' +
                ", courseCategory='" + courseCategory + '\'' +
                ", enrollmentDate=" + enrollmentDate +
                '}';
    }
}
