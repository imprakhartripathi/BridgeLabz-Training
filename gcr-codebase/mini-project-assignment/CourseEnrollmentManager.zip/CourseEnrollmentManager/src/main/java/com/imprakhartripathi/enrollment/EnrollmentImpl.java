package com.imprakhartripathi.enrollment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EnrollmentImpl implements Enrollment {
    protected final List<com.imprakhartripathi.model.Enrollment> storage = new ArrayList<>();

    @Override
    public void add(com.imprakhartripathi.model.Enrollment enrollment) {
        storage.add(enrollment);
    }

    @Override
    public List<com.imprakhartripathi.model.Enrollment> findAll() {
        return Collections.unmodifiableList(storage);
    }
}
