package com.imprakhartripathi.ui;

import com.imprakhartripathi.model.Enrollment;
import com.imprakhartripathi.service.EnrollmentService;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ConsoleApp {
    private final EnrollmentService service;
    private final Scanner scanner;

    public ConsoleApp(EnrollmentService service) {
        this.service = service;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    addEnrollment();
                    break;
                case "2":
                    filterByCourse();
                    break;
                case "3":
                    filterByCategory();
                    break;
                case "4":
                    groupByCourse();
                    break;
                case "5":
                    countByCategory();
                    break;
                case "6":
                    sortByDate();
                    break;
                case "7":
                    listAll();
                    break;
                case "0":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
        System.out.println("Goodbye.");
    }

    private void printMenu() {
        System.out.println("\nOnline Course Enrollment Manager");
        System.out.println("1. Add enrollment");
        System.out.println("2. Filter by course");
        System.out.println("3. Filter by category");
        System.out.println("4. Group by course name");
        System.out.println("5. Count enrollments per category");
        System.out.println("6. Sort by enrollment date");
        System.out.println("7. List all enrollments");
        System.out.println("0. Exit");
        System.out.print("Select an option: ");
    }

    private void addEnrollment() {
        System.out.print("Student name: ");
        String studentName = scanner.nextLine().trim();
        System.out.print("Course name: ");
        String courseName = scanner.nextLine().trim();
        System.out.print("Course category: ");
        String category = scanner.nextLine().trim();
        LocalDate date = readDate("Enrollment date (YYYY-MM-DD): ");

        Enrollment enrollment = new Enrollment(studentName, courseName, category, date);
        service.addEnrollment(enrollment);
        System.out.println("Enrollment added.");
    }

    private void filterByCourse() {
        System.out.print("Course name to filter: ");
        String course = scanner.nextLine().trim();
        List<Enrollment> results = service.filterByCourse(course);
        printList(results);
    }

    private void filterByCategory() {
        System.out.print("Category to filter: ");
        String category = scanner.nextLine().trim();
        List<Enrollment> results = service.filterByCategory(category);
        printList(results);
    }

    private void groupByCourse() {
        Map<String, List<Enrollment>> grouped = service.groupByCourse();
        grouped.forEach((course, list) -> {
            System.out.println("Course: " + course);
            list.forEach(e -> System.out.println("  " + e));
        });
    }

    private void countByCategory() {
        Map<String, Long> counts = service.countByCategory();
        counts.forEach((category, count) -> System.out.println(category + ": " + count));
    }

    private void sortByDate() {
        List<Enrollment> results = service.sortByEnrollmentDate();
        printList(results);
    }

    private void listAll() {
        printList(service.getAllEnrollments());
    }

    private void printList(List<Enrollment> list) {
        if (list.isEmpty()) {
            System.out.println("No enrollments found.");
            return;
        }
        list.forEach(System.out::println);
    }

    private LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return LocalDate.parse(input);
            } catch (DateTimeParseException ex) {
                System.out.println("Invalid date format. Use YYYY-MM-DD.");
            }
        }
    }
}
