package com.imprakhartripathi.service;

import com.imprakhartripathi.model.Enrollment;

import java.util.List;
import java.util.Map;

public interface EnrollmentService {
    void addEnrollment(Enrollment enrollment);

    List<Enrollment> getAllEnrollments();

    List<Enrollment> filterByCourse(String courseName);

    List<Enrollment> filterByCategory(String category);

    Map<String, List<Enrollment>> groupByCourse();

    Map<String, Long> countByCategory();

    List<Enrollment> sortByEnrollmentDate();
}
