package com.imprakhartripathi.service;

import com.imprakhartripathi.enrollment.EnrollmentImpl;
import com.imprakhartripathi.model.Enrollment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EnrollmentServiceTest {
    private EnrollmentService service;

    @BeforeEach
    void setUp() {
        service = new EnrollmentServiceImpl(new EnrollmentImpl());
        service.addEnrollment(new Enrollment("Ava", "Java 8 Fundamentals", "Programming", LocalDate.of(2025, 11, 12)));
        service.addEnrollment(new Enrollment("Liam", "UI/UX Essentials", "Design", LocalDate.of(2025, 10, 5)));
        service.addEnrollment(new Enrollment("Noah", "Data Analysis with Python", "Data Science", LocalDate.of(2025, 9, 18)));
        service.addEnrollment(new Enrollment("Emma", "Java 8 Fundamentals", "Programming", LocalDate.of(2025, 11, 2)));
    }

    @Test
    void filterByCourse_returnsOnlyMatchingCourse() {
        List<Enrollment> results = service.filterByCourse("Java 8 Fundamentals");
        assertEquals(2, results.size());
        assertTrue(results.stream().allMatch(e -> e.getCourseName().equals("Java 8 Fundamentals")));
    }

    @Test
    void filterByCategory_returnsOnlyMatchingCategory() {
        List<Enrollment> results = service.filterByCategory("Design");
        assertEquals(1, results.size());
        assertEquals("UI/UX Essentials", results.get(0).getCourseName());
    }

    @Test
    void groupByCourse_groupsAllEnrollments() {
        Map<String, List<Enrollment>> grouped = service.groupByCourse();
        assertEquals(3, grouped.size());
        assertEquals(2, grouped.get("Java 8 Fundamentals").size());
    }

    @Test
    void countByCategory_countsCorrectly() {
        Map<String, Long> counts = service.countByCategory();
        assertEquals(2L, counts.get("Programming"));
        assertEquals(1L, counts.get("Design"));
        assertEquals(1L, counts.get("Data Science"));
    }

    @Test
    void sortByEnrollmentDate_sortsAscending() {
        List<Enrollment> sorted = service.sortByEnrollmentDate();
        assertEquals(LocalDate.of(2025, 9, 18), sorted.get(0).getEnrollmentDate());
        assertEquals(LocalDate.of(2025, 11, 12), sorted.get(sorted.size() - 1).getEnrollmentDate());
    }
}
